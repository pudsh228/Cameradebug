package com.example.camoverlay

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var stage: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var frameView: FrameView
    private lateinit var fakeButton: View
    private lateinit var settingsButton: View
    private lateinit var galleryButton: View
    private lateinit var shutterButton: View

    private var camera: Camera? = null
    private var useBack = true
    private var torchOn = false

    private val prefs by lazy { getSharedPreferences("s", MODE_PRIVATE) }
    private val tileFile by lazy { File(filesDir, "tile.jpg") }
    private val dp by lazy { resources.displayMetrics.density }

    private val requestCamera =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else {
                Toast.makeText(this, "Нужен доступ к камере", Toast.LENGTH_LONG).show()
                finish()
            }
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let { u ->
                loadBitmap(u)?.let { bmp ->
                    frameView.tile = bmp
                    tileFile.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        stage = findViewById(R.id.stage)
        previewView = findViewById(R.id.previewView)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        frameView = findViewById(R.id.frameView)
        fakeButton = findViewById(R.id.fakeButton)
        settingsButton = findViewById(R.id.settingsButton)
        galleryButton = findViewById(R.id.galleryButton)
        shutterButton = findViewById(R.id.shutterButton)

        frameView.tilesAcross = prefs.getInt("across", 7)
        frameView.tile = if (tileFile.exists()) BitmapFactory.decodeFile(tileFile.path)
                         else BitmapFactory.decodeResource(resources, R.drawable.guy)
        useBack = prefs.getBoolean("back", true)

        // кнопки держим внутри рамки
        stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateMargins() }

        shutterButton.setOnClickListener { takeShot() }
        galleryButton.setOnClickListener { finishAffinity() }     // «выключает приложение»
        fakeButton.setOnClickListener { toggleTorch() }           // фейк-настройки = фонарик
        settingsButton.setOnClickListener { showSettings() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else requestCamera.launch(Manifest.permission.CAMERA)
    }

    private fun updateMargins() {
        if (stage.width == 0) return
        val t = stage.width / frameView.tilesAcross
        val pad = (8 * dp).toInt()
        fun View.setMargins(l: Int, tp: Int, r: Int, b: Int) {
            val lp = layoutParams as FrameLayout.LayoutParams
            if (lp.leftMargin != l || lp.topMargin != tp || lp.rightMargin != r || lp.bottomMargin != b) {
                lp.setMargins(l, tp, r, b)
                layoutParams = lp
            }
        }
        // правая — ровно в углу рамки, левая «фейковая» — чуть ниже и ближе к краю (несимметрично)
        settingsButton.setMargins(0, t + pad, t + pad, 0)
        fakeButton.setMargins(t + pad + (6 * dp).toInt(), t + pad + (10 * dp).toInt(), 0, 0)
        galleryButton.setMargins(t + pad, 0, 0, t + pad)
        shutterButton.setMargins(0, 0, 0, t + pad)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val selector = if (useBack) CameraSelector.DEFAULT_BACK_CAMERA
                           else CameraSelector.DEFAULT_FRONT_CAMERA
            try {
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, selector, preview)
                if (torchOn) camera?.cameraControl?.enableTorch(true)
            } catch (e: Exception) {
                Toast.makeText(this, "Камера недоступна", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleTorch() {
        val cam = camera ?: return
        if (!cam.cameraInfo.hasFlashUnit()) {
            Toast.makeText(this, "У этой камеры нет вспышки", Toast.LENGTH_SHORT).show()
            return
        }
        torchOn = !torchOn
        cam.cameraControl.enableTorch(torchOn)
    }

    private fun showSettings() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_settings, null)
        val seek = v.findViewById<SeekBar>(R.id.sizeSeek)
        // ползунок вправо = фотки крупнее (меньше штук по ширине)
        seek.progress = 20 - frameView.tilesAcross
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                frameView.tilesAcross = 20 - p
                prefs.edit().putInt("across", frameView.tilesAcross).apply()
                updateMargins()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        v.findViewById<Button>(R.id.pickPhoto).setOnClickListener { pickImage.launch("image/*") }
        v.findViewById<Button>(R.id.resetPhoto).setOnClickListener {
            tileFile.delete()
            frameView.tile = BitmapFactory.decodeResource(resources, R.drawable.guy)
        }
        val sw = v.findViewById<SwitchCompat>(R.id.frontSwitch)
        sw.isChecked = !useBack
        sw.setOnCheckedChangeListener { _, checked ->
            useBack = !checked
            prefs.edit().putBoolean("back", useBack).apply()
            startCamera()
        }
        AlertDialog.Builder(this)
            .setTitle("Настройки")
            .setView(v)
            .setPositiveButton("Готово", null)
            .show()
    }

    /** Кадр камеры + рамка -> галерея. */
    private fun takeShot() {
        val frame = previewView.bitmap ?: run {
            Toast.makeText(this, "Камера ещё не готова", Toast.LENGTH_SHORT).show()
            return
        }
        val result = frame.copy(Bitmap.Config.ARGB_8888, true)
        val k = result.width.toFloat() / previewView.width
        val canvas = Canvas(result)
        canvas.scale(k, k)
        frameView.draw(canvas)
        saveToGallery(result)
    }

    private fun saveToGallery(bmp: Bitmap) {
        val name = "CamFrame_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CamOverlay")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(this, "Не удалось сохранить", Toast.LENGTH_SHORT).show()
            return
        }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        Toast.makeText(this, "Сохранено в Pictures/CamOverlay", Toast.LENGTH_SHORT).show()
    }

    /** Загружает картинку из галереи, уменьшает и учитывает поворот из EXIF. */
    private fun loadBitmap(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1500) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return null

        val degrees = try {
            contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }

        if (degrees == 0f) return bmp
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }
}
