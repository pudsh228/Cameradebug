package com.example.camoverlay

import android.app.Activity
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.media.AudioManager
import android.media.ToneGenerator
import kotlin.math.max
import kotlin.random.Random

/** Отдельная скрытая чёрно-белая пиксельная хоррор-новелла. */
class HorrorActivity : Activity() {
    private val white = Color.rgb(232, 232, 232)
    private val dim = Color.rgb(145, 145, 145)
    private val black = Color.rgb(4, 4, 4)
    private lateinit var root: FrameLayout
    private lateinit var story: LinearLayout
    private lateinit var title: TextView
    private lateinit var body: TextView
    private lateinit var monster: PixelWatcher
    private var tone: ToneGenerator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var flicker = false

    private data class Choice(val label: String, val next: String)
    private data class Scene(val heading: String, val text: String, val monster: Boolean = false, val choices: List<Choice>)

    private val scenes = mapOf(
        "start" to Scene("КАССЕТА 01 / 03:17", "Ты включаешь камеру.\nНа экране нет изображения — только серый шум.\n\nИз динамика доносится тихий голос:\n\n«Не фотографируй комнату. Я ещё не готов». ", false, listOf(Choice("Осмотреть экран", "screen"), Choice("Ответить: «Кто здесь?»", "voice"))),
        "screen" to Scene("СИГНАЛ НАЙДЕН", "В отражении видна дверь. В настоящей комнате её нет.\n\nНа плёнке дата: ЗАВТРА.\nПод датой кто-то напечатал: «НЕ ОТКРЫВАЙ». ", true, listOf(Choice("Приблизить отражение", "closer"), Choice("Перемотать кассету", "rewind"))),
        "voice" to Scene("ВТОРОЙ ГОЛОС", "«Ты уже спрашивал», — отвечает голос.\n\n«Каждый раз ты забываешь. Каждый раз я остаюсь на записи».\n\nВ шуме слышится три коротких щелчка.", true, listOf(Choice("Спросить, чего он хочет", "want"), Choice("Выключить звук", "mute"))),
        "closer" to Scene("УВЕЛИЧЕНИЕ x08", "Пиксели складываются в высокий силуэт.\nВместо лица — белый прямоугольник, похожий на пустое окно.\n\nОн не двигается. Но теперь его тень направлена к тебе.", true, listOf(Choice("Посмотреть ещё секунду", "look"), Choice("Закрыть объектив", "cover"))),
        "rewind" to Scene("ПЛЁНКА ПОВРЕЖДЕНА", "Перемотка показывает тот же кадр.\nНа этот раз силуэт стоит ближе к камере.\n\nНа нижнем краю экрана появляется надпись: «СПАСИБО, ЧТО ВЕРНУЛСЯ». ", true, listOf(Choice("Продолжить просмотр", "look"), Choice("Извлечь кассету", "cover"))),
        "want" to Scene("ОТВЕТ", "«Мне нужно, чтобы ты досмотрел запись до конца».\n\n«Тогда я смогу вспомнить своё лицо».\n\nСилуэт медленно поднимает руку. На ладони — нарисованный глаз.", true, listOf(Choice("Досмотреть запись", "look"), Choice("Отказаться", "cover"))),
        "mute" to Scene("ТИШИНА", "Звук исчезает.\nНо субтитры продолжают появляться:\n\n[НЕ СЛЫШУ ТЕБЯ]\n[ТЫ ВСЁ ЕЩЁ СМОТРИШЬ]\n[ПОЗАДИ КАМЕРЫ ЕСТЬ МЕСТО]", true, listOf(Choice("Включить звук", "look"), Choice("Закончить запись", "cover"))),
        "look" to Scene("ПОСЛЕДНИЙ КАДР", "Силуэт заполняет весь экран.\nБелое лицо теперь похоже на фотографию парня с рамки камеры.\n\nНа записи появляется сегодняшняя дата.\nИ время — на одну минуту позже настоящего.", true, listOf(Choice("Оставить запись включённой", "ending_stay"), Choice("Выключить камеру", "ending_leave"))),
        "cover" to Scene("ОБЪЕКТИВ ЗАКРЫТ", "Экран становится чёрным.\nЧерез несколько секунд камера сама делает снимок.\n\nНа фотографии — пустая комната.\nВ углу стоит маленькая фигура и машет рукой.", true, listOf(Choice("Посмотреть финальный кадр", "ending_photo"))),
        "ending_stay" to Scene("КОНЦОВКА: АРХИВ", "Запись заканчивается.\nФайл сохраняется под названием «СЛЕДУЮЩИЙ ОПЕРАТОР».\n\nКогда ты возвращаешься на главный экран, фотография в рамке выглядит чуть иначе.", false, listOf(Choice("Начать заново", "start"))),
        "ending_leave" to Scene("КОНЦОВКА: ОТРАЖЕНИЕ", "Камера выключена.\nНа чёрном экране остаётся отражение комнаты.\n\nСилуэт больше не виден.\nНо отражение моргает с задержкой.", false, listOf(Choice("Начать заново", "start"))),
        "ending_photo" to Scene("КОНЦОВКА: КАДР", "На снимке фигура держит табличку:\n\n«ТЕПЕРЬ ТЫ ЗНАЕШЬ, ГДЕ Я».\n\nКассета автоматически перематывается в начало.", false, listOf(Choice("Начать заново", "start")))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = black
        window.navigationBarColor = black
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, 22)
        buildUi()
        showScene("start")
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(black) }
        val scroll = ScrollView(this)
        story = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(24), dp(22), dp(28))
        }
        scroll.addView(story, ScrollView.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        val back = text("‹  ВЫЙТИ", 13, dim, true).apply {
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setOnClickListener { clickTone(); finish() }
        }
        root.addView(back, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        title = text("", 17, white, true).apply { gravity = Gravity.CENTER; letterSpacing = .12f }
        story.addView(title, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(36) })
        monster = PixelWatcher(this)
        story.addView(monster, LinearLayout.LayoutParams(dp(240), dp(205)).apply { topMargin = dp(22); bottomMargin = dp(16) })
        val rule = text("━━━━━━━━━━━━━━━━━━━━", 12, dim, true).apply { gravity = Gravity.CENTER }
        story.addView(rule)
        body = text("", 15, white, false).apply { gravity = Gravity.CENTER; setLineSpacing(dp(5).toFloat(), 1f) }
        story.addView(body, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22); bottomMargin = dp(26) })
        setContentView(root)
        // Тонкие горизонтальные строки CRT поверх всего экрана.
        val scan = Scanlines(this)
        scan.isClickable = false
        root.addView(scan, FrameLayout.LayoutParams(-1, -1))
    }

    private fun showScene(id: String) {
        val s = scenes[id] ?: return
        title.text = s.heading
        body.text = s.text
        monster.visibility = if (s.monster) View.VISIBLE else View.INVISIBLE
        monster.setAwake(s.monster)
        story.removeViews(4, max(0, story.childCount - 4))
        s.choices.forEachIndexed { index, choice ->
            val b = text("[ ${choice.label.uppercase()} ]", 13, white, true).apply {
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(15), dp(12), dp(15))
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(12, 12, 12)); setStroke(dp(1), Color.rgb(105, 105, 105))
                }
                setOnClickListener { clickTone(); showScene(choice.next) }
            }
            story.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
        }
        if (s.monster) handler.postDelayed({ if (!isFinishing) monster.invalidate() }, 120)
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color); typeface = Typeface.create("monospace", if (bold) Typeface.BOLD else Typeface.NORMAL)
    }

    private fun clickTone() { try { tone?.startTone(ToneGenerator.TONE_PROP_ACK, 55) } catch (_: Exception) {} }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() { handler.removeCallbacksAndMessages(null); tone?.release(); tone = null; super.onDestroy() }

    private class Scanlines(context: android.content.Context) : View(context) {
        private val p = Paint().apply { color = 0x16FFFFFF; strokeWidth = 1f }
        override fun onDraw(canvas: Canvas) { var y = 0f; while (y < height) { canvas.drawLine(0f, y, width.toFloat(), y, p); y += 5f } }
    }

    private class PixelWatcher(context: android.content.Context) : View(context) {
        private val p = Paint().apply { isAntiAlias = false }
        private var awake = false
        fun setAwake(v: Boolean) { awake = v; invalidate() }
        private fun rect(c: Canvas, x: Int, y: Int, w: Int, h: Int, color: Int) { p.color = color; c.drawRect(x.toFloat(), y.toFloat(), (x+w).toFloat(), (y+h).toFloat(), p) }
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val save = canvas.save(); val scale = minOf(width / 32f, height / 27f); canvas.translate((width-32*scale)/2f, (height-27*scale)/2f); canvas.scale(scale, scale)
            rect(canvas, 0,0,32,27,Color.BLACK)
            if (awake) {
                val shades = intArrayOf(0xFF444444.toInt(),0xFF777777.toInt(),0xFFBDBDBD.toInt(),0xFFE7E7E7.toInt())
                // Нечеловеческий силуэт, собранный из крупных пикселей; без крови и травм.
                val rows = arrayOf("...........######...........", ".........##########.........", "........############........", ".......##############.......", "......################......", ".....##################.....", ".....###..########..###......", "....####..########..####.....", "....####################.....", ".....##################......", "......################.......", ".......##############.........", "........############..........", ".........##########...........", ".........##########...........", "........##########............", ".......##########.............", "......##########..............", ".....##########...............", "....##########................", "...##########.................", "..##########..................", "..##########..................", ".##########...................", ".##########...................", "..########....................", "...######.....................")
                rows.forEachIndexed { y, row -> row.forEachIndexed { x, ch -> if (ch == '#') rect(canvas,x,y,1,1,shades[(x+y)%shades.size]) } }
                rect(canvas, 11,8,3,1,Color.WHITE); rect(canvas,18,8,3,1,Color.WHITE)
                rect(canvas, 12,8,1,2,Color.BLACK); rect(canvas,19,8,1,2,Color.BLACK)
                rect(canvas, 14,13,5,1,Color.WHITE)
            } else {
                rect(canvas, 10,5,12,17,0xFF292929.toInt()); rect(canvas,12,8,2,2,0xFFBBBBBB.toInt()); rect(canvas,18,8,2,2,0xFFBBBBBB.toInt())
            }
            // зерно аналоговой записи
            val random = Random(17)
            repeat(38) { val x=random.nextInt(32); val y=random.nextInt(27); rect(canvas,x,y,1,1,if (random.nextBoolean()) 0x55777777 else 0x33999999) }
            canvas.restoreToCount(save)
        }
    }
}
