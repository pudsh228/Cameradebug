package com.example.camoverlay

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var frameView: FrameView
    private lateinit var stage: FrameLayout
    private lateinit var buttons: android.view.View
    private var useBack = true

    private val requestCamera =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else {
                Toast.makeText(this, "Нужен доступ к камере", Toast.LENGTH_LONG).show()
                finish()
            }
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let { u -> loadBitmap(u)?.let { frameView.tile = it } }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        stage = findViewById(R.id.stage)
        previewView = findViewById(R.id.previewView)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        frameView = findViewById(R.id.frameView)
        buttons = findViewById(R.id.buttons)
        // кнопки поднимаем над нижним рядом рамки
        stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateButtonsMargin() }

        // Встроенная картинка по умолчанию
        frameView.tile = BitmapFactory.decodeResource(resources, R.drawable.guy)

        findViewById<Button>(R.id.pickButton).setOnClickListener { pickImage.launch("image/*") }
        findViewById<Button>(R.id.sizeButton).setOnClickListener {
            // по кругу: 4,6,8,10,12 штук по ширине
            val next = frameView.tilesAcross + 2
            frameView.tilesAcross = if (next > 12) 4 else next
            updateButtonsMargin()
        }
        findViewById<Button>(R.id.flipButton).setOnClickListener {
            useBack = !useBack
            startCamera()
        }
        findViewById<Button>(R.id.shotButton).setOnClickListener { takeShot() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else requestCamera.launch(Manifest.permission.CAMERA)
    }

    private fun updateButtonsMargin() {
        if (stage.width == 0) return
        val tile = stage.width / frameView.tilesAcross
        val lp = buttons.layoutParams as FrameLayout.LayoutParams
        if (lp.bottomMargin != tile) {
            lp.bottomMargin = tile
            buttons.layoutParams = lp
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val selector = if (useBack) CameraSelector.DEFAULT_BACK_CAMERA
                           else CameraSelector.DEFAULT_FRONT_CAMERA
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview)
            } catch (e: Exception) {
                Toast.makeText(this, "Камера недоступна", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /** Кадр камеры + рамка -> галерея. */
    private fun takeShot() {
        val frame = previewView.bitmap ?: run {
            Toast.makeText(this, "Камера ещё не готова", Toast.LENGTH_SHORT).show()
            return
        }
        val result = frame.copy(Bitmap.Config.ARGB_8888, true)
        val k = result.width.toFloat() / previewView.width
        val canvas = Canvas(result)
        canvas.scale(k, k)
        frameView.draw(canvas)
        saveToGallery(result)
    }

    private fun saveToGallery(bmp: Bitmap) {
        val name = "CamFrame_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CamOverlay")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(this, "Не удалось сохранить", Toast.LENGTH_SHORT).show()
            return
        }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        Toast.makeText(this, "Сохранено в Pictures/CamOverlay", Toast.LENGTH_SHORT).show()
    }

    /** Загружает картинку из галереи, уменьшает и учитывает поворот из EXIF. */
    private fun loadBitmap(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1500) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return null

        val degrees = try {
            contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }

        if (degrees == 0f) return bmp
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }
}
