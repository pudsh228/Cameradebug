package com.example.camoverlay

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Рисует рамку из множества одинаковых картинок по краям экрана. */
class FrameView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var tile: Bitmap? = null
        set(v) { field = v; invalidate() }

    /** Сколько картинок помещается по ширине (больше — мельче). */
    var tilesAcross = 7
        set(v) { field = v.coerceIn(3, 20); invalidate() }

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val src = Rect()
    private val dst = RectF()

    override fun onDraw(c: Canvas) {
        val b = tile ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val n = tilesAcross
        val t = w / n
        if (h - 2 * t <= 0f) return

        // квадрат из исходной картинки (чуть выше центра — там обычно лицо)
        val side = minOf(b.width, b.height)
        val left = (b.width - side) / 2
        val top = ((b.height - side) * 0.15f).toInt()
        src.set(left, top, left + side, top + side)

        fun put(l: Float, tp: Float, r: Float, bt: Float) {
            dst.set(l, tp, r, bt)
            c.drawBitmap(b, src, dst, paint)
        }

        for (i in 0 until n) {
            put(i * t, 0f, (i + 1) * t, t)          // верх
            put(i * t, h - t, (i + 1) * t, h)       // низ
        }
        val m = maxOf(1, Math.round((h - 2 * t) / t))
        val th = (h - 2 * t) / m
        for (j in 0 until m) {
            val y = t + j * th
            put(0f, y, t, y + th)                   // лево
            put(w - t, y, w, y + th)                // право
        }
    }
}
