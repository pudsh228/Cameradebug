package com.example.camoverlay

import android.content.Context
import org.json.JSONObject
import java.util.Random

data class Item(val id: String, val name: String, val value: Int, val img: String)
data class Drop(val item: Item, val weight: Double)

class Case(val id: String, val name: String, val price: Int, val img: String, val drops: List<Drop>) {
    val total: Double = drops.sumOf { it.weight }

    fun chance(d: Drop): Double = d.weight / total * 100.0

    fun roll(rnd: Random): Item {
        var r = rnd.nextDouble() * total
        for (d in drops) {
            r -= d.weight
            if (r <= 0) return d.item
        }
        return drops.last().item
    }
}

object GameData {
    var items: List<Item> = emptyList()
        private set
    var cases: List<Case> = emptyList()
        private set
    private val byId = HashMap<String, Item>()

    fun load(ctx: Context) {
        if (items.isNotEmpty()) return
        val txt = ctx.assets.open("game.json").bufferedReader().use { it.readText() }
        val root = JSONObject(txt)

        val ia = root.getJSONArray("items")
        val itemList = ArrayList<Item>()
        for (i in 0 until ia.length()) {
            val o = ia.getJSONObject(i)
            val item = Item(o.getString("id"), o.getString("name"), o.getInt("value"), o.getString("img"))
            itemList.add(item)
            byId[item.id] = item
        }
        items = itemList

        val ca = root.getJSONArray("cases")
        val caseList = ArrayList<Case>()
        for (i in 0 until ca.length()) {
            val o = ca.getJSONObject(i)
            val da = o.getJSONArray("drops")
            val drops = ArrayList<Drop>()
            for (k in 0 until da.length()) {
                val pair = da.getJSONArray(k)
                val item = byId[pair.getString(0)] ?: continue
                drops.add(Drop(item, pair.getDouble(1)))
            }
            caseList.add(Case(o.getString("id"), o.getString("name"), o.getInt("price"), o.getString("img"), drops))
        }
        cases = caseList
    }

    fun item(id: String): Item? = byId[id]

    // Цвет и название редкости зависят от цены предмета
    fun rarityColor(value: Int): Int = when {
        value < 15 -> 0xFF9AA3B2.toInt()
        value < 80 -> 0xFF4B8BFF.toInt()
        value < 400 -> 0xFF9B5CFF.toInt()
        value < 2000 -> 0xFFE056D8.toInt()
        value < 10000 -> 0xFFFF4D4D.toInt()
        else -> 0xFFFFC21F.toInt()
    }

    fun rarityName(value: Int): String = when {
        value < 15 -> "Хлам"
        value < 80 -> "Норм"
        value < 400 -> "Редкий"
        value < 2000 -> "Эпик"
        value < 10000 -> "Мифик"
        else -> "Абсурд"
    }

    /** 1234567 -> "1 234 567" */
    fun money(v: Long): String {
        val s = v.toString()
        val sb = StringBuilder()
        for (i in s.indices) {
            if (i > 0 && (s.length - i) % 3 == 0) sb.append(' ')
            sb.append(s[i])
        }
        return sb.toString()
    }
}
