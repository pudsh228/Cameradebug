package com.example.camoverlay

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.Random
import kotlin.math.min

private val BG = 0xFF0E0F1F.toInt()
private val PANEL = 0xFF1A1C38.toInt()
private val PANEL2 = 0xFF2D3166.toInt()
private val GOLD = 0xFFFFC21F.toInt()
private val GREEN = 0xFF22C55E.toInt()
private val RED = 0xFFFF4D4D.toInt()
private val MUTED = 0xFF9AA3B2.toInt()
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Секретная игра: кейсы, апгрейд, инвентарь. Только виртуальные монеты. */
class GameActivity : Activity() {

    private lateinit var store: GameStore
    private lateinit var fx: SoundFx
    private val rnd = Random()
    private val handler = Handler(Looper.getMainLooper())
    private val cache = HashMap<String, Bitmap>()
    private val d: Float by lazy { resources.displayMetrics.density }

    private lateinit var content: FrameLayout
    private lateinit var balanceView: TextView
    private lateinit var claimBtn: TextView
    private lateinit var confetti: ConfettiView
    private lateinit var flash: View
    private val tabViews = ArrayList<TextView>()

    private var tab = 0
    private var currentCase: Case? = null
    private var busy = false
    private var openCount = 1
    private var lastWins: List<Item> = emptyList()
    private lateinit var countLabel: TextView
    private var fastToggleText: TextView? = null
    private var caseOpenButton: TextView? = null
    private var profileFastToggle: TextView? = null
    private var upgradeFastToggle: TextView? = null

    // состояние экрана апгрейда
    private val sel = HashMap<String, Int>()
    private var target: Item? = null
    private lateinit var wheel: WheelView
    private lateinit var upInfo: TextView
    private lateinit var upResult: TextView
    private lateinit var upBtn: TextView
    private lateinit var upMine: GridLayout
    private lateinit var upTargets: GridLayout

    private val ticker = object : Runnable {
        override fun run() {
            updateClaim()
            handler.postDelayed(this, 1000)
        }
    }

    // ---------- жизненный цикл ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GameData.load(this)
        store = GameStore(this)
        fx = SoundFx(this)

        val root = FrameLayout(this)
        root.setBackgroundColor(BG)
        root.fitsSystemWindows = true

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        // шапка с названием проекта
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(8), dp(8), dp(12), dp(8))
        header.setBackgroundColor(PANEL)

        val close = tv("✕", 20f, MUTED, true, true)
        close.setPadding(dp(8), dp(4), dp(10), dp(4))
        close.setOnClickListener { fx.play("click"); onBackPressed() }
        header.addView(close, LinearLayout.LayoutParams(WRAP, WRAP))

        val brand = tv("MURZO CASES", 16f, Color.WHITE, true, true)
        header.addView(brand, LinearLayout.LayoutParams(0, WRAP, 1f))
        balanceView = tv("", 18f, GOLD, true, true)
        header.addView(balanceView, LinearLayout.LayoutParams(WRAP, WRAP))

        claimBtn = tv("", 14f, Color.WHITE, true, true)
        claimBtn.setPadding(dp(12), dp(8), dp(12), dp(8))
        claimBtn.setOnClickListener { onClaim() }
        header.addView(claimBtn, LinearLayout.LayoutParams(WRAP, WRAP))
        col.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        content = FrameLayout(this)
        col.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // вкладки
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setBackgroundColor(PANEL)
        val labels = listOf("▦", "◉", "♙")
        val descriptions = listOf("Кейсы", "Апгрейд", "Профиль")
        for ((i, label) in labels.withIndex()) {
            val t = tv(label, 25f, MUTED, true, true)
            t.contentDescription = descriptions[i]
            t.setPadding(0, dp(10), 0, dp(10))
            t.setOnClickListener { fx.play("click"); selectTab(i) }
            tabs.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
            tabViews.add(t)
        }
        col.addView(tabs, LinearLayout.LayoutParams(MATCH, WRAP))

        confetti = ConfettiView(this)
        root.addView(confetti, FrameLayout.LayoutParams(MATCH, MATCH))
        flash = View(this)
        flash.alpha = 0f
        root.addView(flash, FrameLayout.LayoutParams(MATCH, MATCH))

        // Короткий декоративный экран загрузки с прокруткой колеса.
        val splash = LinearLayout(this)
        splash.orientation = LinearLayout.VERTICAL
        splash.gravity = Gravity.CENTER
        splash.setBackgroundColor(BG)
        val splashTitle = tv("MURZO CASES", 28f, Color.WHITE, true, true)
        splash.addView(splashTitle)
        val splashWheel = WheelView(this)
        splashWheel.chance = 0.28f
        splashWheel.centerText = "MURZO"
        splashWheel.subText = "загрузка"
        splash.addView(splashWheel, LinearLayout.LayoutParams(dp(190), dp(190)).apply { topMargin = dp(22) })
        root.addView(splash, FrameLayout.LayoutParams(MATCH, MATCH))
        splashWheel.animate().rotationBy(720f).setDuration(1450).start()

        setContentView(root)
        updateBalance(false)
        updateClaim()
        selectTab(0)
        handler.postDelayed({
            splash.animate().alpha(0f).setDuration(220).withEndAction { root.removeView(splash) }.start()
        }, 1450)
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        store.save()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        fx.release()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (busy) return
        if (currentCase != null) selectTab(0) else finish()
    }

    // ---------- вспомогательное ----------

    private fun dp(v: Int): Int = (v * d).toInt()

    private fun bg(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radius * d
        if (strokeW > 0) g.setStroke(dp(strokeW), strokeColor)
        return g
    }

    private fun tv(label: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false, center: Boolean = false): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        if (center) t.gravity = Gravity.CENTER
        return t
    }

    private fun button(label: String, color: Int, textColor: Int = Color.WHITE, onClick: () -> Unit): TextView {
        val b = tv(label, 16f, textColor, true, true)
        b.background = bg(color, 22f)
        b.setPadding(dp(16), dp(14), dp(16), dp(14))
        b.setOnClickListener { fx.play("click"); onClick() }
        return b
    }

    private fun bitmap(path: String): Bitmap? {
        cache[path]?.let { return it }
        return try {
            val b = assets.open(path).use { BitmapFactory.decodeStream(it) }
            if (b != null) cache[path] = b
            b
        } catch (e: Exception) {
            null
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun fmt1(p: Double): String =
        if (p < 0.1) String.format(Locale.US, "%.2f%%", p) else String.format(Locale.US, "%.1f%%", p)

    private fun updateBalance(pulse: Boolean) {
        balanceView.text = "🪙 " + GameData.money(store.balance)
        if (pulse) {
            balanceView.animate().scaleX(1.25f).scaleY(1.25f).setDuration(120).withEndAction {
                balanceView.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }.start()
        }
    }

    private fun updateClaim() {
        val left = store.claimLeftMs()
        if (left <= 0) {
            claimBtn.text = "🎁 +${GameStore.HOURLY_REWARD}"
            claimBtn.background = bg(GREEN, 12f)
            claimBtn.animate().scaleX(1.1f).scaleY(1.1f).setDuration(300).withEndAction {
                claimBtn.animate().scaleX(1f).scaleY(1f).setDuration(300).start()
            }.start()
        } else {
            val s = left / 1000
            claimBtn.text = String.format(Locale.US, "⏳ %02d:%02d", s / 60, s % 60)
            claimBtn.background = bg(PANEL2, 12f)
        }
    }

    private fun onClaim() {
        if (store.claim()) {
            fx.play("coin")
            confetti.burst(50, 0.85f, 0.04f, 0.8f)
            updateBalance(true)
            updateClaim()
        } else {
            val s = store.claimLeftMs() / 1000
            toast(String.format(Locale.US, "Следующая награда через %02d:%02d", s / 60, s % 60))
        }
    }

    private fun flash(color: Int, maxAlpha: Float) {
        flash.setBackgroundColor(color)
        flash.alpha = 0f
        flash.animate().alpha(maxAlpha).setDuration(110).withEndAction {
            flash.animate().alpha(0f).setDuration(600).start()
        }.start()
    }

    private fun shake(v: View) {
        ObjectAnimator.ofFloat(v, View.TRANSLATION_X, 0f, 22f, -22f, 16f, -16f, 9f, -9f, 0f)
            .setDuration(480).start()
    }

    private fun roundOutline(v: View, radius: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius * d)
            }
        }
        v.clipToOutline = true
    }

    private fun itemImage(item: Item, size: Int): ImageView {
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.setImageBitmap(bitmap(item.img))
        roundOutline(iv, 10f)
        iv.layoutParams = LinearLayout.LayoutParams(size, size)
        return iv
    }

    private val cellW: Int
        get() = (resources.displayMetrics.widthPixels - dp(24) - dp(24)) / 3

    private fun addCell(g: GridLayout, v: View, width: Int = cellW) {
        val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED))
        lp.width = width
        lp.height = WRAP
        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
        g.addView(v, lp)
    }

    /** Карточка предмета: картинка, название, подпись, бейдж «xN». */
    private fun itemCell(item: Item, badge: String?, caption: String, selected: Boolean, onClick: () -> Unit): View {
        val rar = GameData.rarityColor(item.value)
        val fl = FrameLayout(this)
        fl.background = bg(if (selected) PANEL2 else PANEL, 12f, rar, if (selected) 3 else 1)
        fl.setPadding(dp(6), dp(6), dp(6), dp(6))
        fl.setOnClickListener { onClick() }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(itemImage(item, cellW - dp(12)))
        val name = tv(item.name, 10.5f, Color.WHITE, false, true)
        name.maxLines = 2
        name.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(name, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        col.addView(tv(caption, 11.5f, rar, true, true))
        fl.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        if (badge != null) {
            val b = tv(badge, 11f, Color.WHITE, true, true)
            b.background = bg(0xCC000000.toInt(), 8f)
            b.setPadding(dp(6), dp(1), dp(6), dp(1))
            val lp = FrameLayout.LayoutParams(WRAP, WRAP)
            lp.gravity = Gravity.TOP or Gravity.END
            fl.addView(b, lp)
        }
        return fl
    }

    private fun sectionTitle(s: String): TextView {
        val t = tv(s, 15f, Color.WHITE, true)
        t.setPadding(dp(4), dp(16), dp(4), dp(4))
        return t
    }

    // ---------- вкладки ----------

    private fun selectTab(i: Int) {
        if (busy) return
        tab = i
        currentCase = null
        for ((k, t) in tabViews.withIndex()) {
            t.setTextColor(if (k == i) GOLD else MUTED)
            t.setBackgroundColor(if (k == i) PANEL2 else PANEL)
        }
        content.removeAllViews()
        content.addView(
            when (i) {
                0 -> buildCases()
                1 -> buildUpgrade()
                else -> buildProfile()
            },
            FrameLayout.LayoutParams(MATCH, MATCH)
        )
    }

    // ---------- КЕЙСЫ ----------

    private fun buildCases(): View {
        val sv = ScrollView(this)
        val g = GridLayout(this)
        g.columnCount = 2
        g.setPadding(dp(8), dp(8), dp(8), dp(16))
        val w = (resources.displayMetrics.widthPixels - dp(16) - dp(16)) / 2
        for (c in GameData.cases) addCell(g, caseCard(c), w)
        sv.addView(g)
        return sv
    }

    private fun caseCard(c: Case): View {
        val afford = store.balance >= c.price
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.background = bg(PANEL, 22f, if (afford) GOLD else 0xFF2A2D52.toInt(), 1)
        col.setPadding(dp(8), dp(10), dp(8), dp(12))
        col.setOnClickListener { fx.play("click"); showCase(c) }

        val img = ImageView(this)
        img.setImageBitmap(bitmap(c.img))
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        col.addView(img, LinearLayout.LayoutParams(dp(110), dp(110)))
        val name = tv(c.name, 13f, Color.WHITE, true, true)
        name.maxLines = 2
        name.ellipsize = android.text.TextUtils.TruncateAt.END
        name.minLines = 2
        col.addView(name, LinearLayout.LayoutParams(MATCH, WRAP))
        val price = tv("🪙 " + GameData.money(c.price.toLong()), 15f, if (afford) GOLD else RED, true, true)
        col.addView(price, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        return col
    }

    private fun showCase(c: Case) {
        if (busy) return
        currentCase = c
        content.removeAllViews()
        content.addView(buildCaseDetail(c), FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun openLabel(c: Case): String = "ОТКРЫТЬ ×$openCount  ·  🪙 ${GameData.money(c.price.toLong() * openCount)}"

    private fun buildCaseDetail(c: Case): View {
        openCount = 1
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(8), dp(12), dp(24))
        sv.addView(col)

        val back = tv("‹ Все кейсы", 15f, MUTED, true)
        back.setPadding(dp(4), dp(8), dp(4), dp(8))
        back.setOnClickListener { fx.play("click"); selectTab(0) }
        col.addView(back)

        col.addView(tv(c.name, 20f, Color.WHITE, true, true), LinearLayout.LayoutParams(MATCH, WRAP))

        val roulette = RouletteView(this) { bitmap(it.img) }
        roulette.setIdle(List(12) { c.roll(rnd) })
        col.addView(roulette, LinearLayout.LayoutParams(MATCH, dp(140)).apply { topMargin = dp(10) })

        val countRow = LinearLayout(this)
        countRow.gravity = Gravity.CENTER
        countRow.background = bg(PANEL, 18f)
        val minus = button("−", PANEL2) { openCount = maxOf(1, openCount - 1); countLabel.text = "×$openCount"; caseOpenButton?.text = openLabel(c) }
        countLabel = tv("×1", 17f, Color.WHITE, true, true)
        val plus = button("+", PANEL2) { openCount = minOf(10, openCount + 1); countLabel.text = "×$openCount"; caseOpenButton?.text = openLabel(c) }
        countRow.addView(minus, LinearLayout.LayoutParams(dp(54), WRAP))
        countRow.addView(countLabel, LinearLayout.LayoutParams(dp(72), WRAP))
        countRow.addView(plus, LinearLayout.LayoutParams(dp(54), WRAP))
        col.addView(countRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        val fastToggle = button(if (store.fastMode) "⚡ Быстрое открытие: ВКЛ" else "⚡ Быстрое открытие: ВЫКЛ", PANEL2) {
            store.fastMode = !store.fastMode; store.save()
            fastToggleText?.text = if (store.fastMode) "⚡ Быстрое открытие: ВКЛ" else "⚡ Быстрое открытие: ВЫКЛ"
        }
        fastToggleText = fastToggle
        col.addView(fastToggle, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        val openBtn = button(openLabel(c), GREEN) {}
        caseOpenButton = openBtn
        col.addView(openBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        // панель результата
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER_HORIZONTAL
        panel.background = bg(PANEL, 22f)
        panel.setPadding(dp(12), dp(12), dp(12), dp(12))
        panel.visibility = View.GONE
        val resImg = ImageView(this)
        resImg.scaleType = ImageView.ScaleType.CENTER_CROP
        roundOutline(resImg, 14f)
        panel.addView(resImg, LinearLayout.LayoutParams(dp(140), dp(140)))
        val resName = tv("", 17f, Color.WHITE, true, true)
        panel.addView(resName, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        val resInfo = tv("", 14f, MUTED, true, true)
        panel.addView(resInfo, LinearLayout.LayoutParams(MATCH, WRAP))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val sellBtn = button("", GOLD, Color.BLACK) {}
        val keepBtn = button("Оставить", PANEL2) {}
        row.addView(sellBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
        row.addView(keepBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
        panel.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        col.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        // содержимое кейса с шансами
        col.addView(sectionTitle("Что внутри (шанс выпадения)"))
        val g = GridLayout(this)
        g.columnCount = 3
        for (drop in c.drops.sortedByDescending { it.item.value }) {
            addCell(g, itemCell(drop.item, null, "🪙 ${GameData.money(drop.item.value.toLong())}\n${fmt1(c.chance(drop))}", false) {})
        }
        col.addView(g)

        lastWins = emptyList()
        keepBtn.setOnClickListener { fx.play("click"); panel.visibility = View.GONE }
        sellBtn.setOnClickListener {
            var total = 0L
            for (w in lastWins) if (store.remove(w.id, 1)) total += w.value
            if (total > 0) {
                store.balance += total
                store.save()
                fx.play("coin")
                updateBalance(true)
            }
            lastWins = emptyList()
            panel.visibility = View.GONE
        }

        openBtn.setOnClickListener {
            if (busy) return@setOnClickListener
            val totalCost = c.price.toLong() * openCount
            if (store.balance < totalCost) {
                toast("Не хватает монет. Награда раз в час, или продай предметы!")
                return@setOnClickListener
            }
            panel.visibility = View.GONE
            store.balance -= totalCost
            val wins = (0 until openCount).map { c.roll(rnd) }
            lastWins = wins
            wins.forEach { store.add(it.id) }
            store.opened += openCount
            store.save()
            updateBalance(false)
            val win = wins.last()
            val saleTotal = wins.sumOf { it.value.toLong() }
            sellBtn.text = "Продать всё · 🪙 ${GameData.money(saleTotal)}"
            resName.text = if (wins.size == 1) win.name else "Открыто кейсов: ${wins.size}"
            resInfo.text = if (wins.size == 1) "${GameData.rarityName(win.value)} · 🪙 ${GameData.money(win.value.toLong())}"
                else "Последний предмет: ${win.name} · всего предметов добавлено в инвентарь"

            val finishOpen = {
                busy = false
                openBtn.alpha = 1f
                revealResult(c, win, panel, resImg, resName, resInfo, sellBtn)
                sellBtn.text = "Продать всё · 🪙 ${GameData.money(saleTotal)}"
                if (wins.size > 1) {
                    resName.text = "Открыто кейсов: ${wins.size}"
                    resInfo.text = wins.sortedByDescending { it.value }.take(3).joinToString(" · ") { it.name }
                }
            }
            if (store.fastMode) {
                resImg.setImageBitmap(bitmap(win.img))
                finishOpen()
            } else {
                val len = 64
                val tIdx = 54 + rnd.nextInt(5)
                val strip = ArrayList<Item>()
                for (k in 0 until len) strip.add(c.roll(rnd))
                strip[tIdx] = win
                busy = true
                openBtn.alpha = 0.45f
                fx.play("whoosh", 0.8f)
                roulette.spin(strip, tIdx, 0.12f + 0.76f * rnd.nextFloat(), 6800,
                    { speed -> fx.tick(speed) }, { finishOpen() })
            }
        }
        return sv
    }

    private fun revealResult(
        c: Case, win: Item, panel: View, img: ImageView,
        name: TextView, info: TextView, sell: TextView
    ) {
        val rar = GameData.rarityColor(win.value)
        img.setImageBitmap(bitmap(win.img))
        name.text = win.name
        name.setTextColor(rar)
        val ratio = win.value.toDouble() / c.price
        info.text = "${GameData.rarityName(win.value)} · 🪙 ${GameData.money(win.value.toLong())}"
        sell.text = "Продать 🪙 ${GameData.money(win.value.toLong())}"
        panel.visibility = View.VISIBLE
        panel.scaleX = 0.6f
        panel.scaleY = 0.6f
        panel.alpha = 0f
        panel.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(380)
            .setInterpolator(OvershootInterpolator(2.2f)).start()

        when {
            ratio >= 10 -> {
                fx.play("win3"); fx.play("coin", 0.9f, 1.1f)
                confetti.burst(240, 0.5f, 0.45f, 1.35f); confetti.rain(140)
                flash(rar, 0.6f); shake(content)
            }
            ratio >= 3 -> {
                fx.play("win3")
                confetti.burst(150, 0.5f, 0.45f, 1.15f)
                flash(rar, 0.42f)
            }
            ratio >= 1 -> {
                fx.play("win2")
                confetti.burst(60, 0.5f, 0.45f, 0.9f)
                flash(rar, 0.25f)
            }
            else -> fx.play("win1")
        }
    }

    // ---------- АПГРЕЙД ----------

    private fun selValue(): Long {
        var s = 0L
        for ((id, n) in sel) s += (GameData.item(id)?.value ?: 0).toLong() * n
        return s
    }

    private fun upChance(sum: Long, t: Item): Double = min(0.95, sum.toDouble() / t.value * 0.92)

    private fun buildUpgrade(): View {
        sel.clear()
        target = null
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(8), dp(12), dp(24))
        sv.addView(col)

        wheel = WheelView(this)
        col.addView(wheel, LinearLayout.LayoutParams(dp(250), dp(250)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })
        upInfo = tv("", 14f, MUTED, true, true)
        col.addView(upInfo, LinearLayout.LayoutParams(MATCH, WRAP))
        upBtn = button("АПГРЕЙД", GREEN) { doUpgrade() }
        col.addView(upBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        val quickUpgrade = button(if (store.fastMode) "⚡ Быстрый апгрейд: ВКЛ" else "⚡ Быстрый апгрейд: ВЫКЛ", PANEL2) {
            store.fastMode = !store.fastMode; store.save()
            upgradeFastToggle?.text = if (store.fastMode) "⚡ Быстрый апгрейд: ВКЛ" else "⚡ Быстрый апгрейд: ВЫКЛ"
        }
        upgradeFastToggle = quickUpgrade
        col.addView(quickUpgrade, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        upResult = tv("", 15f, Color.WHITE, true, true)
        col.addView(upResult, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        col.addView(sectionTitle("1. Твои предметы (тап — добавить, ещё тап — больше копий)"))
        upMine = GridLayout(this)
        upMine.columnCount = 3
        col.addView(upMine)

        col.addView(sectionTitle("2. Цель (чем дороже — тем меньше шанс)"))
        upTargets = GridLayout(this)
        upTargets.columnCount = 3
        col.addView(upTargets)

        refreshUpgrade()
        return sv
    }

    private fun refreshUpgrade() {
        val sum = selValue()
        val t = target
        if (t != null && (sum <= 0 || t.value <= sum)) target = null
        val tt = target

        // мои предметы
        upMine.removeAllViews()
        val mine = store.inv.keys.mapNotNull { GameData.item(it) }.sortedByDescending { it.value }
        if (mine.isEmpty()) {
            upMine.addView(tv("Пока пусто. Открой кейсы!", 14f, MUTED, false, true))
        }
        for (item in mine) {
            val have = store.count(item.id)
            val picked = sel[item.id] ?: 0
            addCell(upMine, itemCell(item, if (picked > 0) "$picked/$have" else "x$have",
                "🪙 ${GameData.money(item.value.toLong())}", picked > 0) {
                if (busy) return@itemCell
                fx.play("click")
                val next = picked + 1
                if (next > have) sel.remove(item.id) else sel[item.id] = next
                upResult.text = ""
                refreshUpgrade()
            })
        }

        // цели
        upTargets.removeAllViews()
        if (sum <= 0) {
            upTargets.addView(tv("Сначала выбери свои предметы", 14f, MUTED, false, true))
        } else {
            val list = GameData.items.filter { it.value > sum && sum.toDouble() / it.value * 0.92 >= 0.02 }
                .sortedBy { it.value }.take(60)
            if (list.isEmpty()) upTargets.addView(tv("Нет целей дороже. Добавь предметов.", 14f, MUTED, false, true))
            for (item in list) {
                val ch = upChance(sum, item) * 100
                addCell(upTargets, itemCell(item, null, "🪙 ${GameData.money(item.value.toLong())}\n${fmt1(ch)}",
                    tt?.id == item.id) {
                    if (busy) return@itemCell
                    fx.play("click")
                    target = item
                    upResult.text = ""
                    refreshUpgrade()
                })
            }
        }

        // колесо и подписи
        if (tt != null && sum > 0) {
            val ch = upChance(sum, tt)
            wheel.chance = ch.toFloat()
            wheel.centerText = fmt1(ch * 100)
            wheel.subText = "шанс успеха"
            upInfo.text = "Ставка 🪙 ${GameData.money(sum)}  →  Цель 🪙 ${GameData.money(tt.value.toLong())}"
            upBtn.alpha = 1f
        } else {
            wheel.chance = 0f
            wheel.centerText = "—"
            wheel.subText = ""
            upInfo.text = if (sum > 0) "Ставка 🪙 ${GameData.money(sum)} — выбери цель" else "Выбери предметы и цель"
            upBtn.alpha = 0.45f
        }
    }

    private fun doUpgrade() {
        val t = target
        val sum = selValue()
        if (busy || t == null || sum <= 0) {
            toast("Выбери свои предметы и цель")
            return
        }
        val chance = upChance(sum, t)
        val win = rnd.nextDouble() < chance
        for ((id, n) in sel) store.remove(id, n)
        if (win) store.add(t.id)
        store.save()

        busy = true
        upBtn.alpha = 0.45f
        upResult.text = ""
        fx.play("whoosh", 0.7f)
        val completeUpgrade = {
            busy = false
            if (win) {
                fx.play("up_ok")
                confetti.burst(170, 0.5f, 0.35f, 1.2f)
                flash(GREEN, 0.4f)
                upResult.text = "🎉 Успех! Получено: ${t.name}"
                upResult.setTextColor(GREEN)
            } else {
                fx.play("up_fail")
                shake(wheel)
                flash(RED, 0.25f)
                upResult.text = "💥 Не повезло. Предметы сгорели"
                upResult.setTextColor(RED)
            }
            sel.clear()
            target = null
            refreshUpgrade()
        }
        if (store.fastMode) completeUpgrade() else wheel.spin(win, { fx.tick(0.35f) }, completeUpgrade)
    }

    // ---------- ПРОФИЛЬ И ИНВЕНТАРЬ ----------

    private fun buildProfile(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(14), dp(14), dp(28))
        sv.addView(col)

        col.addView(tv("Профиль игрока", 22f, Color.WHITE, true, true), LinearLayout.LayoutParams(MATCH, WRAP))
        val avatar = ImageView(this)
        avatar.scaleType = ImageView.ScaleType.CENTER_CROP
        avatar.background = bg(PANEL2, 60f, 0xFF7777AA.toInt(), 2)
        avatar.setImageResource(android.R.drawable.sym_def_app_icon)
        store.avatarUri?.let { uri -> try { avatar.setImageURI(Uri.parse(uri)) } catch (_: Exception) {} }
        roundOutline(avatar, 60f)
        col.addView(avatar, LinearLayout.LayoutParams(dp(104), dp(104)).apply { gravity = Gravity.CENTER; topMargin = dp(16) })
        val avatarBtn = button("Изменить аватар", PANEL2) {
            val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(android.content.Intent.CATEGORY_OPENABLE); addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
            startActivityForResult(intent, 401)
        }
        col.addView(avatarBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        val nick = EditText(this)
        nick.setSingleLine(true)
        nick.setText(store.nickname)
        nick.setTextColor(Color.WHITE)
        nick.setHintTextColor(MUTED)
        nick.hint = "Твой ник"
        nick.background = bg(PANEL, 16f)
        nick.setPadding(dp(16), dp(12), dp(16), dp(12))
        col.addView(nick, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        col.addView(button("Сохранить профиль", GREEN) {
            store.nickname = nick.text.toString().trim().ifBlank { "Игрок" }.take(20)
            store.save(); nick.setText(store.nickname); toast("Профиль сохранён")
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        val profileFast = button(if (store.fastMode) "⚡ Быстрые анимации: ВКЛ" else "⚡ Быстрые анимации: ВЫКЛ", PANEL2) {
            store.fastMode = !store.fastMode; store.save()
            profileFastToggle?.text = if (store.fastMode) "⚡ Быстрые анимации: ВКЛ" else "⚡ Быстрые анимации: ВЫКЛ"
        }
        profileFastToggle = profileFast
        col.addView(profileFast, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        val best = store.bestItemValue()
        val bestCard = LinearLayout(this)
        bestCard.orientation = LinearLayout.VERTICAL
        bestCard.background = bg(PANEL, 20f)
        bestCard.setPadding(dp(16), dp(14), dp(16), dp(14))
        bestCard.addView(tv("ТВОЙ ЛУЧШИЙ ЛОТ", 12f, MUTED, true))
        bestCard.addView(tv(store.bestItemName(), 17f, GOLD, true), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(5) })
        bestCard.addView(tv("🪙 ${GameData.money(best.toLong())} · всего предметов: ${store.totalCount()}", 13f, MUTED))
        col.addView(bestCard, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) })

        col.addView(sectionTitle("Локальный топ игроков"))
        val rank = LinearLayout(this)
        rank.orientation = LinearLayout.HORIZONTAL
        rank.gravity = Gravity.CENTER_VERTICAL
        rank.background = bg(PANEL2, 18f)
        rank.setPadding(dp(14), dp(14), dp(14), dp(14))
        rank.addView(tv("#1", 20f, GOLD, true), LinearLayout.LayoutParams(dp(48), WRAP))
        rank.addView(tv("${store.nickname}\nСамый дорогой предмет: ${GameData.money(best.toLong())} монет", 14f, Color.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        col.addView(rank, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(tv("Рейтинг хранится на этом устройстве. Для настоящего общего топа понадобится онлайн-сервер.", 12f, MUTED), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        col.addView(sectionTitle("Инвентарь"))
        col.addView(tv("Предметов: ${store.totalCount()} · стоимость: 🪙 ${GameData.money(store.totalValue())}", 13f, MUTED, true))
        if (store.totalCount() > 0) col.addView(button("Продать всё", GOLD, Color.BLACK) { confirmSellAll() }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        val g = GridLayout(this); g.columnCount = 3
        val items = store.inv.keys.mapNotNull { GameData.item(it) }.sortedByDescending { it.value }
        if (items.isEmpty()) col.addView(tv("Пока нет предметов. Открой кейс!", 14f, MUTED, false, true), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(18) })
        for (item in items) addCell(g, itemCell(item, "x${store.count(item.id)}", "🪙 ${GameData.money(item.value.toLong())}", false) { itemDialog(item) })
        col.addView(g, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        return sv
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 401 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                store.avatarUri = uri.toString()
                try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                store.save(); selectTab(2)
            }
        }
    }

    private fun buildInventory(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(12), dp(12), dp(24))
        sv.addView(col)

        col.addView(
            tv("Предметов: ${store.totalCount()}  ·  стоимость 🪙 ${GameData.money(store.totalValue())}", 15f, Color.WHITE, true, true),
            LinearLayout.LayoutParams(MATCH, WRAP)
        )
        col.addView(tv("Открыто кейсов: ${store.opened}", 12f, MUTED, false, true), LinearLayout.LayoutParams(MATCH, WRAP))

        if (store.totalCount() > 0) {
            val sellAll = button("Продать всё", GOLD, Color.BLACK) { confirmSellAll() }
            col.addView(sellAll, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        }

        val g = GridLayout(this)
        g.columnCount = 3
        val items = store.inv.keys.mapNotNull { GameData.item(it) }.sortedByDescending { it.value }
        if (items.isEmpty()) {
            col.addView(tv("Тут пока пусто.\nОткрой кейс, и предметы появятся здесь.", 15f, MUTED, false, true),
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(40) })
        }
        for (item in items) {
            addCell(g, itemCell(item, "x${store.count(item.id)}", "🪙 ${GameData.money(item.value.toLong())}", false) {
                fx.play("click")
                itemDialog(item)
            })
        }
        col.addView(g, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        return sv
    }

    private fun darkDialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun itemDialog(item: Item) {
        val n = store.count(item.id)
        if (n <= 0) return
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.gravity = Gravity.CENTER_HORIZONTAL
        v.setPadding(dp(16), dp(16), dp(16), dp(8))
        v.addView(itemImage(item, dp(160)))
        v.addView(tv(item.name, 17f, GameData.rarityColor(item.value), true, true),
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        v.addView(tv("${GameData.rarityName(item.value)} · 🪙 ${GameData.money(item.value.toLong())} · у тебя: $n",
            13f, MUTED, false, true), LinearLayout.LayoutParams(MATCH, WRAP))

        val b = darkDialog().setView(v)
            .setPositiveButton("Продать 1") { _, _ -> sell(item, 1) }
            .setNegativeButton("Закрыть", null)
        if (n > 1) b.setNeutralButton("Продать все ($n)") { _, _ -> sell(item, n) }
        b.show()
    }

    private fun sell(item: Item, n: Int) {
        if (!store.remove(item.id, n)) return
        store.balance += item.value.toLong() * n
        store.save()
        fx.play("coin")
        updateBalance(true)
        selectTab(2)
    }

    private fun confirmSellAll() {
        val total = store.totalValue()
        darkDialog()
            .setTitle("Продать всё?")
            .setMessage("Ты получишь 🪙 ${GameData.money(total)}")
            .setPositiveButton("Продать") { _, _ ->
                store.balance += total
                store.inv.clear()
                store.save()
                fx.play("coin")
                confetti.burst(60, 0.5f, 0.2f, 0.9f)
                updateBalance(true)
                selectTab(2)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}
