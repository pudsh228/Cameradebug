package com.example.camoverlay

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.SystemClock
import java.util.Random

class SoundFx(ctx: Context) {
    private val pool: SoundPool
    private val ids = HashMap<String, Int>()
    private val rnd = Random()
    private var lastTick = 0L
    var enabled: Boolean = true

    init {
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        pool = SoundPool.Builder().setMaxStreams(12).setAudioAttributes(attrs).build()
        ids["tick"] = pool.load(ctx, R.raw.g_tick, 1)
        ids["click"] = pool.load(ctx, R.raw.g_click, 1)
        ids["whoosh"] = pool.load(ctx, R.raw.g_whoosh, 1)
        ids["win1"] = pool.load(ctx, R.raw.g_win1, 1)
        ids["win2"] = pool.load(ctx, R.raw.g_win2, 1)
        ids["win3"] = pool.load(ctx, R.raw.g_win3, 1)
        ids["coin"] = pool.load(ctx, R.raw.g_coin, 1)
        ids["up_ok"] = pool.load(ctx, R.raw.g_up_ok, 1)
        ids["up_fail"] = pool.load(ctx, R.raw.g_up_fail, 1)
    }

    fun play(name: String, vol: Float = 1f, rate: Float = 1f) {
        if (!enabled) return
        val id = ids[name] ?: return
        // Общая тихая громкость: никаких резких пиков, все эффекты звучат мягко.
        val soundGain = when (name) {
            "click" -> 0.72f
            "tick" -> 0.62f
            "coin" -> 0.58f
            "whoosh" -> 0.52f
            else -> 0.56f
        }
        val actualVol = (vol * soundGain).coerceIn(0f, 0.62f)
        // Небольшая вариация тона делает нажатия похожими на мягкую механическую клавиатуру.
        val actualRate = if (name == "click" || name == "tick") {
            rate * (0.97f + 0.045f * rnd.nextFloat())
        } else rate
        pool.play(id, actualVol, actualVol, 1, 0, actualRate)
    }

    /** Мягкий «клавиатурный» тик; speed 0..1 чуть поднимает тон на быстрой прокрутке. */
    fun tick(speed: Float) {
        if (!enabled) return
        val now = SystemClock.uptimeMillis()
        if (now - lastTick < 38) return
        lastTick = now
        val rate = 0.96f + 0.07f * speed + 0.035f * rnd.nextFloat()
        play("tick", 0.38f + 0.18f * rnd.nextFloat(), rate)
    }

    fun release() {
        pool.release()
    }
}
