package com.example.camoverlay

import android.content.Context
import org.json.JSONObject

/** Сохранение: баланс, инвентарь, время последней награды. Всё виртуальное. */
class GameStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("game", Context.MODE_PRIVATE)

    var balance: Long = sp.getLong("balance", 100L)
    var lastClaim: Long = sp.getLong("claim", -1L)
    var lastFiveClaim: Long = sp.getLong("five_claim", -1L)
    var fractionalTenths: Int = sp.getInt("fractional_tenths", 0)
    var opened: Int = sp.getInt("opened", 0)
    var nickname: String = sp.getString("nickname", "Игрок") ?: "Игрок"
    var avatarUri: String? = sp.getString("avatar", null)
    var fastOpen: Boolean = sp.getBoolean("fast_open", sp.getBoolean("fast_mode", false))
    var fastUpgrade: Boolean = sp.getBoolean("fast_upgrade", false)
    var bestItemId: String? = sp.getString("best_item_id", null)
    val inv = LinkedHashMap<String, Int>()

    companion object {
        const val HOUR_MS = 3_600_000L
        const val HOURLY_REWARD = 100L
    }

    init {
        val now = System.currentTimeMillis()
        if (lastClaim < 0 || lastClaim > now) lastClaim = now
        val s = sp.getString("inv", null)
        if (s != null) {
            try {
                val o = JSONObject(s)
                for (k in o.keys()) inv[k] = o.getInt(k)
            } catch (e: Exception) {
                inv.clear()
            }
        }
        // Однократная миграция: если рекорд ещё не сохранялся отдельно,
        // переносим лучший предмет из старого инвентаря.
        if (bestItemId.isNullOrBlank()) {
            bestItemId = inv.keys.mapNotNull { GameData.item(it) }.maxByOrNull { it.value }?.id
            if (bestItemId != null) save()
        }
    }

    fun save() {
        val o = JSONObject()
        for ((k, v) in inv) if (v > 0) o.put(k, v)
        sp.edit()
            .putLong("balance", balance)
            .putLong("claim", lastClaim)
            .putLong("five_claim", lastFiveClaim)
            .putInt("fractional_tenths", fractionalTenths)
            .putInt("opened", opened)
            .putString("nickname", nickname)
            .putString("avatar", avatarUri)
            .putBoolean("fast_open", fastOpen)
            .putBoolean("fast_upgrade", fastUpgrade)
            .putString("best_item_id", bestItemId)
            .putString("inv", o.toString())
            .apply()
    }

    fun count(id: String): Int = inv[id] ?: 0

    fun add(id: String, n: Int = 1) {
        inv[id] = count(id) + n
    }

    fun remove(id: String, n: Int = 1): Boolean {
        val c = count(id)
        if (c < n) return false
        if (c == n) inv.remove(id) else inv[id] = c - n
        return true
    }

    fun totalCount(): Int = inv.values.sum()

    fun recordBest(item: Item) {
        val current = bestItemId?.let { GameData.item(it) }
        if (current == null || item.value > current.value) {
            bestItemId = item.id
            save()
        }
    }

    fun bestItem(): Item? = bestItemId?.let { GameData.item(it) }
    fun bestItemValue(): Int = bestItem()?.value ?: 0
    fun bestItemName(): String = bestItem()?.name ?: "Пока нет предметов"

    fun totalValue(): Long {
        var s = 0L
        for ((k, v) in inv) s += (GameData.item(k)?.value ?: 0).toLong() * v
        return s
    }

    fun addTenthCoin() {
        fractionalTenths += 1
        if (fractionalTenths >= 10) {
            balance += fractionalTenths / 10
            fractionalTenths %= 10
        }
        save()
    }

    fun fiveMinuteLeftMs(): Long = maxOf(0L, lastFiveClaim + 300_000L - System.currentTimeMillis())

    fun claimFiveMinutes(): Boolean {
        if (lastFiveClaim > 0 && fiveMinuteLeftMs() > 0) return false
        balance += 10L
        lastFiveClaim = System.currentTimeMillis()
        save()
        return true
    }

    fun claimLeftMs(): Long {
        val now = System.currentTimeMillis()
        if (lastClaim > now) lastClaim = now
        return maxOf(0L, lastClaim + HOUR_MS - now)
    }

    /** Раз в час +100 монет, чтобы игра никогда не заканчивалась. */
    fun claim(): Boolean {
        if (claimLeftMs() > 0) return false
        balance += HOURLY_REWARD
        lastClaim = System.currentTimeMillis()
        save()
        return true
    }
}
