package com.example.camoverlay

/** Тексты экрана настроек на разных языках. */
object L {
    const val EGYPT = 0

    val names = listOf("🏺👁️🐍", "Русский", "Français", "Татарча", "Кирпичный")

    private val egypt = mapOf(
        "title" to "🔺⚙️🏺",
        "lang" to "🌍🗣️👁️",
        "size" to "🖼️📏↔️",
        "pick" to "👆🖼️➕",
        "reset" to "🔄🖼️🏠",
        "front" to "🤳📷🐫",
        "bee" to "🐝🔊5️⃣⏳",
        "done" to "✅"
    )

    private val ru = mapOf(
        "title" to "Настройки",
        "lang" to "Язык интерфейса",
        "size" to "Размер фоток по бокам",
        "pick" to "Выбрать фотку для рамки",
        "reset" to "Вернуть фотку по умолчанию",
        "front" to "Фронтальная камера",
        "bee" to "Жужжание пчелы раз в 5 секунд",
        "done" to "Готово"
    )

    private val fr = mapOf(
        "title" to "Paramètres",
        "lang" to "Langue de l’interface",
        "size" to "Taille des photos sur les côtés",
        "pick" to "Choisir la photo du cadre",
        "reset" to "Rétablir la photo par défaut",
        "front" to "Caméra frontale",
        "bee" to "Bourdonnement d’abeille toutes les 5 secondes",
        "done" to "Terminé"
    )

    private val tt = mapOf(
        "title" to "Көйләүләр",
        "lang" to "Интерфейс теле",
        "size" to "Ян-яктагы рәсемнәрнең зурлыгы",
        "pick" to "Рамка өчен рәсем сайлау",
        "reset" to "Стандарт рәсемне кире кайтару",
        "front" to "Алгы камера",
        "bee" to "Һәр 5 секунд саен бал корты безелдәве",
        "done" to "Әзер"
    )

    /** «Кирпичный язык»: после каждой гласной буквы добавляем «к». */
    fun brick(s: String): String {
        val vowels = "аеёиоуыэюяАЕЁИОУЫЭЮЯ"
        val sb = StringBuilder()
        for (c in s) {
            sb.append(c)
            if (c in vowels) sb.append('к')
        }
        return sb.toString()
    }

    private val brick = ru.mapValues { brick(it.value) }

    val all = listOf(egypt, ru, fr, tt, brick)
}
