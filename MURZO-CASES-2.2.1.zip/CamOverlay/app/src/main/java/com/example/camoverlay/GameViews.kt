package com.example.camoverlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import java.util.Random
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

private val easeOutQuart = TimeInterpolator { t ->
    val u = 1f - t
    1f - u * u * u * u
}

/** Горизонтальная рулетка кейса: карточки едут, тики звучат на каждой карточке. */
class RouletteView(ctx: Context, private val bmp: (Item) -> Bitmap?) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val cardW = 100f * d
    private val gap = 8f * d
    private val step = cardW + gap
    private val bgColor = 0xFF14152B.toInt()

    private var strip: List<Item> = emptyList()
    private var scroll = 0f
    private var highlight = -1
    private var pulse = 0f
    private var anim: ValueAnimator? = null
    private var pulseAnim: ValueAnimator? = null

    var spinning = false
        private set

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 12f * d
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val src = Rect()
    private val dst = RectF()
    private val path = Path()
    private var leftShader: Shader? = null
    private var rightShader: Shader? = null

    init {
        setOnClickListener { if (spinning) anim?.end() }   // тап = пропустить анимацию
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val fade = 60f * d
        leftShader = LinearGradient(0f, 0f, fade, 0f, bgColor, 0x0014152B, Shader.TileMode.CLAMP)
        rightShader = LinearGradient(w - fade, 0f, w.toFloat(), 0f, 0x0014152B, bgColor, Shader.TileMode.CLAMP)
    }

    fun setIdle(items: List<Item>) {
        stopAnims()
        strip = items
        highlight = -1
        scroll = 3 * step + cardW / 2f
        invalidate()
    }

    private fun stopAnims() {
        anim?.removeAllListeners()
        anim?.cancel()
        pulseAnim?.cancel()
        spinning = false
    }

    fun spin(
        items: List<Item>, target: Int, frac: Float, durationMs: Long,
        onTick: (Float) -> Unit, onEnd: () -> Unit
    ) {
        stopAnims()
        strip = items
        highlight = -1
        val start = 3 * step + cardW / 2f
        val end = target * step + frac * cardW
        scroll = start
        spinning = true
        var lastIdx = floor(start / step).toInt()
        val a = ValueAnimator.ofFloat(start, end)
        a.duration = durationMs
        a.interpolator = easeOutQuart
        a.addUpdateListener { v ->
            scroll = v.animatedValue as Float
            val idx = floor(scroll / step).toInt()
            if (idx != lastIdx) {
                lastIdx = idx
                onTick(1f - v.animatedFraction)
            }
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                scroll = end
                spinning = false
                highlight = target
                startPulse()
                invalidate()
                onEnd()
            }
        })
        anim = a
        a.start()
    }

    private fun startPulse() {
        pulseAnim?.cancel()
        val p = ValueAnimator.ofFloat(0f, 1f)
        p.duration = 650
        p.repeatCount = ValueAnimator.INFINITE
        p.repeatMode = ValueAnimator.REVERSE
        p.addUpdateListener { v ->
            pulse = v.animatedValue as Float
            invalidate()
        }
        pulseAnim = p
        p.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        anim?.removeAllListeners()
        anim?.cancel()
        pulseAnim?.cancel()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = bgColor
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, 14f * d, 14f * d, paint)

        c.save()
        path.reset()
        path.addRoundRect(rect, 14f * d, 14f * d, Path.Direction.CW)
        c.clipPath(path)

        if (strip.isNotEmpty()) {
            val first = max(0, floor((scroll - w / 2f) / step).toInt())
            val last = min(strip.size - 1, ceil((scroll + w / 2f) / step).toInt())
            for (i in first..last) drawCard(c, i, w, h)
        }

        val fade = 60f * d
        paint.shader = leftShader
        c.drawRect(0f, 0f, fade, h, paint)
        paint.shader = rightShader
        c.drawRect(w - fade, 0f, w, h, paint)
        paint.shader = null

        // золотой маркер по центру
        paint.color = 0x33FFC21F
        c.drawRect(w / 2f - 5f * d, 0f, w / 2f + 5f * d, h, paint)
        paint.color = 0xFFFFC21F.toInt()
        c.drawRect(w / 2f - 1.5f * d, 0f, w / 2f + 1.5f * d, h, paint)
        path.reset()
        path.moveTo(w / 2f - 9f * d, 0f); path.lineTo(w / 2f + 9f * d, 0f); path.lineTo(w / 2f, 12f * d); path.close()
        c.drawPath(path, paint)
        path.reset()
        path.moveTo(w / 2f - 9f * d, h); path.lineTo(w / 2f + 9f * d, h); path.lineTo(w / 2f, h - 12f * d); path.close()
        c.drawPath(path, paint)
        c.restore()
    }

    private fun drawCard(c: Canvas, i: Int, w: Float, h: Float) {
        val item = strip[i]
        val left = w / 2f - scroll + i * step
        val top = 8f * d
        val bottom = h - 8f * d
        val rar = GameData.rarityColor(item.value)

        c.save()
        if (i == highlight) {
            val s = 1.05f + 0.03f * pulse
            c.scale(s, s, left + cardW / 2f, h / 2f)
        }
        paint.style = Paint.Style.FILL
        rect.set(left, top, left + cardW, bottom)
        paint.color = 0xFF1F2145.toInt()
        c.drawRoundRect(rect, 12f * d, 12f * d, paint)

        val pad = 6f * d
        val side = cardW - 2f * pad
        dst.set(left + pad, top + pad, left + pad + side, top + pad + side)
        val b = bmp(item)
        if (b != null) {
            src.set(0, 0, b.width, b.height)
            path.reset()
            path.addRoundRect(dst, 9f * d, 9f * d, Path.Direction.CW)
            c.save()
            c.clipPath(path)
            c.drawBitmap(b, src, dst, paint)
            c.restore()
        }
        c.drawText(GameData.money(item.value.toLong()), left + cardW / 2f, top + pad + side + 16f * d, textPaint)

        paint.color = rar
        rect.set(left + pad, bottom - 7f * d, left + cardW - pad, bottom - 3f * d)
        c.drawRoundRect(rect, 2f * d, 2f * d, paint)

        if (i == highlight) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f * d
            paint.color = rar
            paint.alpha = (140 + 115 * pulse).toInt()
            rect.set(left, top, left + cardW, bottom)
            c.drawRoundRect(rect, 12f * d, 12f * d, paint)
            paint.alpha = 255
            paint.style = Paint.Style.FILL
        }
        c.restore()
    }
}

/** Колесо апгрейда: зелёный сектор = шанс успеха, стрелка крутится и тормозит. */
class WheelView(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val rnd = Random()

    var chance = 0f
        set(v) { field = v; invalidate() }
    var centerText = "—"
        set(v) { field = v; invalidate() }
    var subText = ""
        set(v) { field = v; invalidate() }

    private var angle = 0f
    private var anim: ValueAnimator? = null
    var spinning = false
        private set

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }
    private val rect = RectF()
    private val path = Path()

    fun spin(win: Boolean, onTick: () -> Unit, onEnd: () -> Unit) {
        anim?.removeAllListeners()
        anim?.cancel()
        val sweep = chance * 360f
        val margin = max(1.5f, min(8f, min(sweep, 360f - sweep) * 0.12f))
        val fin = if (win) {
            margin + rnd.nextFloat() * max(0.1f, sweep - 2 * margin)
        } else {
            sweep + margin + rnd.nextFloat() * max(0.1f, 360f - sweep - 2 * margin)
        }
        val start = angle % 360f
        val end = 360f * 6 + fin
        angle = start
        spinning = true
        var lastK = floor(start / 12f).toInt()
        val a = ValueAnimator.ofFloat(start, end)
        a.duration = 5400
        a.interpolator = easeOutQuart
        a.addUpdateListener { v ->
            angle = v.animatedValue as Float
            val k = floor(angle / 12f).toInt()
            if (k != lastK) {
                lastK = k
                onTick()
            }
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                angle = end
                spinning = false
                invalidate()
                onEnd()
            }
        })
        anim = a
        a.start()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        anim?.removeAllListeners()
        anim?.cancel()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val sw = 18f * d
        val r = min(w, h) / 2f - sw - 10f * d
        rect.set(cx - r, cy - r, cx + r, cy + r)

        fill.color = 0xFF14152B.toInt()
        c.drawCircle(cx, cy, r + sw / 2f + 4f * d, fill)

        ring.strokeWidth = sw
        ring.color = 0x66FF4D4D
        c.drawArc(rect, 0f, 360f, false, ring)
        if (chance > 0f) {
            ring.color = 0xFF22C55E.toInt()
            c.drawArc(rect, -90f, chance * 360f, false, ring)
        }
        // насечки
        ring.strokeWidth = 2f * d
        ring.color = 0x33FFFFFF
        for (k in 0 until 30) {
            val a = Math.toRadians(k * 12.0 - 90.0)
            c.drawLine(
                cx + (r - sw / 2f - 2f * d) * cos(a).toFloat(), cy + (r - sw / 2f - 2f * d) * kotlin.math.sin(a).toFloat(),
                cx + (r - sw / 2f - 8f * d) * cos(a).toFloat(), cy + (r - sw / 2f - 8f * d) * kotlin.math.sin(a).toFloat(), ring
            )
        }

        // стрелка
        c.save()
        c.rotate(angle, cx, cy)
        ring.strokeWidth = 3f * d
        ring.color = 0x88FFFFFF.toInt()
        c.drawLine(cx, cy - r * 0.55f, cx, cy - r + sw / 2f, ring)
        fill.color = Color.WHITE
        path.reset()
        path.moveTo(cx - 11f * d, cy - r - sw / 2f - 12f * d)
        path.lineTo(cx + 11f * d, cy - r - sw / 2f - 12f * d)
        path.lineTo(cx, cy - r + sw / 2f + 2f * d)
        path.close()
        c.drawPath(path, fill)
        c.restore()

        text.textSize = 27f * d
        c.drawText(centerText, cx, cy + 8f * d, text)
        if (subText.isNotEmpty()) {
            text.textSize = 12f * d
            text.color = 0xFF9AA3B2.toInt()
            c.drawText(subText, cx, cy + 30f * d, text)
            text.color = Color.WHITE
        }
    }
}

/** Конфетти: взрыв вверх + падающий дождь. */
class ConfettiView(ctx: Context) : View(ctx) {
    private class P(
        var x: Float, var y: Float, var vx: Float, var vy: Float,
        var rot: Float, val vr: Float, val color: Int, val w: Float, val h: Float, var life: Float
    )

    private val d = ctx.resources.displayMetrics.density
    private val ps = ArrayList<P>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random()
    private var last = 0L
    private val colors = intArrayOf(
        0xFFFFC21F.toInt(), 0xFFFF4D4D.toInt(), 0xFF22C55E.toInt(), 0xFF4B8BFF.toInt(),
        0xFFE056D8.toInt(), 0xFF9B5CFF.toInt(), 0xFFFFFFFF.toInt()
    )

    fun burst(count: Int, xFrac: Float, yFrac: Float, power: Float) {
        val ox = width * xFrac
        val oy = height * yFrac
        for (i in 0 until count) {
            val ang = Math.toRadians(-90.0 + (rnd.nextDouble() - 0.5) * 150.0)
            val sp = (500f + rnd.nextFloat() * 1100f) * d * power
            ps.add(
                P(
                    ox, oy, (cos(ang) * sp).toFloat(), (kotlin.math.sin(ang) * sp).toFloat(),
                    rnd.nextFloat() * 360f, (rnd.nextFloat() - 0.5f) * 720f,
                    colors[rnd.nextInt(colors.size)], (5f + rnd.nextFloat() * 6f) * d, (8f + rnd.nextFloat() * 8f) * d,
                    2.8f + rnd.nextFloat() * 1.6f
                )
            )
        }
        kick()
    }

    fun rain(count: Int) {
        for (i in 0 until count) {
            ps.add(
                P(
                    rnd.nextFloat() * width, -rnd.nextFloat() * height * 0.5f,
                    (rnd.nextFloat() - 0.5f) * 120f * d, (150f + rnd.nextFloat() * 250f) * d,
                    rnd.nextFloat() * 360f, (rnd.nextFloat() - 0.5f) * 540f,
                    colors[rnd.nextInt(colors.size)], (5f + rnd.nextFloat() * 6f) * d, (8f + rnd.nextFloat() * 8f) * d,
                    4f + rnd.nextFloat() * 2f
                )
            )
        }
        kick()
    }

    private fun kick() {
        last = System.nanoTime()
        postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = min(0.05f, (now - last) / 1e9f)
        last = now
        val it = ps.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.vy += 1500f * d * dt
            p.vx *= 0.995f
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.rot += p.vr * dt
            p.life -= dt
            if (p.y > height + 60f * d || p.life < 0f) {
                it.remove()
                continue
            }
            paint.color = p.color
            c.save()
            c.translate(p.x, p.y)
            c.rotate(p.rot)
            val flutter = max(0.15f, abs(cos(Math.toRadians((p.rot * 2.0)).toFloat())))
            c.drawRect(-p.w / 2f, -p.h * flutter / 2f, p.w / 2f, p.h * flutter / 2f, paint)
            c.restore()
        }
        if (ps.isNotEmpty()) postInvalidateOnAnimation()
    }
}
