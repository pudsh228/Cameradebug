package com.example.camoverlay

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlay: ImageView

    private val requestCamera =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else {
                Toast.makeText(this, "Нужен доступ к камере", Toast.LENGTH_LONG).show()
                finish()
            }
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                overlay.setImageURI(it)
                overlay.visibility = ImageView.VISIBLE
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        // COMPATIBLE (TextureView) нужен, чтобы previewView.bitmap работал стабильно
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        overlay = findViewById(R.id.overlay)

        findViewById<Button>(R.id.pickButton).setOnClickListener { pickImage.launch("image/*") }
        findViewById<Button>(R.id.shotButton).setOnClickListener { takeShot() }

        setupOverlayGestures()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else requestCamera.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview)
        }, ContextCompat.getMainExecutor(this))
    }

    /** Перетаскивание одним пальцем, масштаб — щипком. */
    private fun setupOverlayGestures() {
        val scaleDetector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(d: ScaleGestureDetector): Boolean {
                    val s = (overlay.scaleX * d.scaleFactor).coerceIn(0.2f, 8f)
                    overlay.scaleX = s
                    overlay.scaleY = s
                    return true
                }
            })

        var lastX = 0f
        var lastY = 0f
        var dragging = false

        // Слушаем касания на всём экране, чтобы пальцем можно было тянуть откуда угодно
        previewView.setOnTouchListener { _, e ->
            if (overlay.visibility != ImageView.VISIBLE) return@setOnTouchListener false
            scaleDetector.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastX = e.x; lastY = e.y; dragging = true
                }
                MotionEvent.ACTION_MOVE -> if (dragging && !scaleDetector.isInProgress && e.pointerCount == 1) {
                    overlay.translationX += e.x - lastX
                    overlay.translationY += e.y - lastY
                    lastX = e.x; lastY = e.y
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    // после щипка не прыгаем: берём координаты оставшегося пальца
                    val i = if (e.actionIndex == 0) 1 else 0
                    lastX = e.getX(i); lastY = e.getY(i)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
            }
            true
        }
    }

    /** Кадр камеры + картинка поверх -> галерея. */
    private fun takeShot() {
        val frame = previewView.bitmap ?: run {
            Toast.makeText(this, "Камера ещё не готова", Toast.LENGTH_SHORT).show()
            return
        }
        val result = frame.copy(Bitmap.Config.ARGB_8888, true)
        if (overlay.visibility == ImageView.VISIBLE) {
            val k = result.width.toFloat() / previewView.width
            val canvas = Canvas(result)
            canvas.scale(k, k)
            canvas.translate(overlay.left + overlay.translationX, overlay.top + overlay.translationY)
            canvas.scale(overlay.scaleX, overlay.scaleY, overlay.width / 2f, overlay.height / 2f)
            overlay.draw(canvas)
        }
        saveToGallery(result)
    }

    private fun saveToGallery(bmp: Bitmap) {
        val name = "CamOverlay_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CamOverlay")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(this, "Не удалось сохранить", Toast.LENGTH_SHORT).show()
            return
        }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        Toast.makeText(this, "Сохранено в Pictures/CamOverlay", Toast.LENGTH_SHORT).show()
    }
}
