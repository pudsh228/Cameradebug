package com.example.camoverlay

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.Random
import kotlin.math.min

private val BG = 0xFF100D20.toInt()
private val PANEL = 0xFF211936.toInt()
private val PANEL2 = 0xFF49316F.toInt()
private val GOLD = 0xFFFFD36E.toInt()
private val GREEN = 0xFF8DDBB1.toInt()
private val RED = 0xFFFF4D4D.toInt()
private val MUTED = 0xFFB9AEC9.toInt()
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Секретная игра: кейсы, апгрейд, инвентарь. Только виртуальные монеты. */
class GameActivity : Activity() {

    private lateinit var store: GameStore
    private lateinit var fx: SoundFx
    private val rnd = Random()
    private val handler = Handler(Looper.getMainLooper())
    private val cache = HashMap<String, Bitmap>()
    private val d: Float by lazy { resources.displayMetrics.density }

    private lateinit var content: FrameLayout
    private lateinit var balanceView: TextView
    private lateinit var confetti: ConfettiView
    private lateinit var flash: View
    private val tabViews = ArrayList<TextView>()
    private lateinit var earnFiveLabel: TextView
    private lateinit var earnHourLabel: TextView
    private var clickerClicks = 0

    private var tab = 0
    private var currentCase: Case? = null
    private var busy = false
    private var openCount = 1
    private var lastWins: List<Item> = emptyList()
    private lateinit var countLabel: TextView
    private var fastToggleText: TextView? = null
    private var caseOpenButton: TextView? = null
    private var upgradeFastToggle: TextView? = null

    // состояние экрана апгрейда
    private val sel = HashMap<String, Int>()
    private var target: Item? = null
    private lateinit var wheel: WheelView
    private lateinit var upInfo: TextView
    private lateinit var upResult: TextView
    private lateinit var upBtn: TextView
    private lateinit var upMine: GridLayout
    private lateinit var upTargets: GridLayout

    private val ticker = object : Runnable {
        override fun run() {
            if (tab == 2) refreshEarnTimers()
            handler.postDelayed(this, 1000)
        }
    }

    // ---------- жизненный цикл ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        GameData.load(this)
        store = GameStore(this)
        fx = SoundFx(this)

        val root = FrameLayout(this)
        root.background = bg(BG, 0f)
        root.fitsSystemWindows = true

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        // шапка с названием проекта
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(12), dp(10), dp(12), dp(10))
        header.background = bg(0xFF251A3C.toInt(), 0f)

        val close = tv("✕", 20f, MUTED, true, true)
        close.setPadding(dp(8), dp(4), dp(10), dp(4))
        close.setOnClickListener { fx.play("click"); onBackPressed() }
        header.addView(close, LinearLayout.LayoutParams(WRAP, WRAP))

        val brand = tv("MURZO CASES", 18f, Color.WHITE, true, true)
        header.addView(brand, LinearLayout.LayoutParams(0, WRAP, 1f))
        balanceView = tv("", 18f, GOLD, true, true)
        header.addView(balanceView, LinearLayout.LayoutParams(WRAP, WRAP))

        col.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        content = FrameLayout(this)
        col.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // вкладки
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.setBackgroundColor(PANEL)
        val labels = listOf("▦", "🎮", "♙")
        val descriptions = listOf("Кейсы", "Игры", "Профиль")
        for ((i, label) in labels.withIndex()) {
            val t = tv(label, 25f, MUTED, true, true)
            t.contentDescription = descriptions[i]
            t.setPadding(0, dp(12), 0, dp(12))
            t.setOnClickListener { fx.play("click"); selectTab(i) }
            tabs.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
            tabViews.add(t)
        }
        col.addView(tabs, LinearLayout.LayoutParams(MATCH, WRAP))

        val snow = SnowView(this)
        snow.isClickable = false
        snow.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        root.addView(snow, FrameLayout.LayoutParams(MATCH, MATCH))

        confetti = ConfettiView(this)
        root.addView(confetti, FrameLayout.LayoutParams(MATCH, MATCH))
        flash = View(this)
        flash.alpha = 0f
        root.addView(flash, FrameLayout.LayoutParams(MATCH, MATCH))

        // Короткий декоративный экран загрузки с прокруткой колеса.
        val splash = LinearLayout(this)
        splash.orientation = LinearLayout.VERTICAL
        splash.gravity = Gravity.CENTER
        splash.setBackgroundColor(BG)
        val splashTitle = tv("MURZO CASES", 28f, Color.WHITE, true, true)
        splash.addView(splashTitle)
        val splashWheel = WheelView(this)
        splashWheel.chance = 0.28f
        splashWheel.centerText = "MURZO"
        splashWheel.subText = "загрузка"
        splash.addView(splashWheel, LinearLayout.LayoutParams(dp(190), dp(190)).apply { topMargin = dp(22) })
        root.addView(splash, FrameLayout.LayoutParams(MATCH, MATCH))
        splashWheel.animate().rotationBy(720f).setDuration(1450).start()

        setContentView(root)
        updateBalance(false)
        selectTab(0)
        handler.postDelayed({
            splash.animate().alpha(0f).setDuration(220).withEndAction { root.removeView(splash) }.start()
        }, 1450)
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        store.save()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        fx.release()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (busy) return
        if (currentCase != null) selectTab(0) else finish()
    }

    // ---------- вспомогательное ----------

    private fun dp(v: Int): Int = (v * d).toInt()

    private fun bg(color: Int, radius: Float, strokeColor: Int = 0, strokeW: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = radius * d
        if (strokeW > 0) g.setStroke(dp(strokeW), strokeColor)
        return g
    }

    private fun tv(label: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false, center: Boolean = false): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        if (center) t.gravity = Gravity.CENTER
        return t
    }

    private fun button(label: String, color: Int, textColor: Int = Color.WHITE, onClick: () -> Unit): TextView {
        val b = tv(label, 16f, textColor, true, true)
        b.background = bg(color, 22f)
        b.setPadding(dp(16), dp(14), dp(16), dp(14))
        b.setOnClickListener { fx.play("click"); onClick() }
        return b
    }

    private fun bitmap(path: String): Bitmap? {
        cache[path]?.let { return it }
        return try {
            val b = assets.open(path).use { BitmapFactory.decodeStream(it) }
            if (b != null) cache[path] = b
            b
        } catch (e: Exception) {
            null
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun fmt1(p: Double): String =
        if (p < 0.1) String.format(Locale.US, "%.2f%%", p) else String.format(Locale.US, "%.1f%%", p)

    private fun updateBalance(pulse: Boolean) {
        balanceView.text = "🪙 " + GameData.money(store.balance) + if (store.fractionalTenths > 0) ".${store.fractionalTenths}" else ""
        if (pulse) {
            balanceView.animate().scaleX(1.25f).scaleY(1.25f).setDuration(120).withEndAction {
                balanceView.animate().scaleX(1f).scaleY(1f).setDuration(160).start()
            }.start()
        }
    }

    private fun flash(color: Int, maxAlpha: Float) {
        flash.setBackgroundColor(color)
        flash.alpha = 0f
        flash.animate().alpha(maxAlpha).setDuration(110).withEndAction {
            flash.animate().alpha(0f).setDuration(600).start()
        }.start()
    }

    private fun shake(v: View) {
        ObjectAnimator.ofFloat(v, View.TRANSLATION_X, 0f, 22f, -22f, 16f, -16f, 9f, -9f, 0f)
            .setDuration(480).start()
    }

    private fun roundOutline(v: View, radius: Float) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, radius * d)
            }
        }
        v.clipToOutline = true
    }

    private fun itemImage(item: Item, size: Int): ImageView {
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.setImageBitmap(bitmap(item.img))
        roundOutline(iv, 10f)
        iv.layoutParams = LinearLayout.LayoutParams(size, size)
        return iv
    }

    private val cellW: Int
        get() = (resources.displayMetrics.widthPixels - dp(24) - dp(24)) / 3

    private fun addCell(g: GridLayout, v: View, width: Int = cellW) {
        val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED))
        lp.width = width
        lp.height = WRAP
        lp.setMargins(dp(4), dp(4), dp(4), dp(4))
        g.addView(v, lp)
    }

    /** Карточка предмета: картинка, название, подпись, бейдж «xN». */
    private fun itemCell(item: Item, badge: String?, caption: String, selected: Boolean, onClick: () -> Unit): View {
        val rar = GameData.rarityColor(item.value)
        val fl = FrameLayout(this)
        fl.background = bg(if (selected) PANEL2 else PANEL, 12f, rar, if (selected) 3 else 1)
        fl.setPadding(dp(6), dp(6), dp(6), dp(6))
        fl.setOnClickListener { onClick() }

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(itemImage(item, cellW - dp(12)))
        val name = tv(item.name, 10.5f, Color.WHITE, false, true)
        name.maxLines = 2
        name.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(name, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        col.addView(tv(caption, 11.5f, rar, true, true))
        fl.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        if (badge != null) {
            val b = tv(badge, 11f, Color.WHITE, true, true)
            b.background = bg(0xCC000000.toInt(), 8f)
            b.setPadding(dp(6), dp(1), dp(6), dp(1))
            val lp = FrameLayout.LayoutParams(WRAP, WRAP)
            lp.gravity = Gravity.TOP or Gravity.END
            fl.addView(b, lp)
        }
        return fl
    }

    private fun sectionTitle(s: String): TextView {
        val t = tv(s, 15f, Color.WHITE, true)
        t.setPadding(dp(4), dp(16), dp(4), dp(4))
        return t
    }

    // ---------- вкладки ----------

    private fun selectTab(i: Int) {
        if (busy) return
        tab = i
        currentCase = null
        for ((k, t) in tabViews.withIndex()) {
            t.setTextColor(if (k == i) 0xFFFFD36E.toInt() else MUTED)
            t.setBackgroundColor(if (k == i) 0xFF49316F.toInt() else 0xFF251A3C.toInt())
        }
        content.removeAllViews()
        content.addView(
            when (i) {
                0 -> buildCases()
                1 -> buildGamesHub()
                else -> buildProfile()
            },
            FrameLayout.LayoutParams(MATCH, MATCH)
        )
    }

    // ---------- КЕЙСЫ ----------

    private fun buildCases(): View {
        val sv = ScrollView(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(20))
        }
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(0xFF35234F.toInt(), 26f, 0xFF62458A.toInt(), 1)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        hero.addView(tv("MURZO CASES", 12f, 0xFFD4B8FF.toInt(), true))
        hero.addView(tv("Твоя следующая\nнаходка уже ждёт", 23f, Color.WHITE, true), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        hero.addView(tv("Выбирай кейс и попробуй удачу", 13f, 0xFFD0C4DF.toInt()), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(7) })
        page.addView(hero, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(10) })
        page.addView(tv("Кейсы", 20f, Color.WHITE, true), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8); bottomMargin = dp(6) })
        val g = GridLayout(this)
        g.columnCount = 2
        g.setPadding(0, dp(4), 0, dp(16))
        val w = (resources.displayMetrics.widthPixels - dp(40)) / 2
        for (c in GameData.cases) addCell(g, caseCard(c), w)
        page.addView(g)
        sv.addView(page)
        return sv
    }

    private fun caseCard(c: Case): View {
        val afford = store.balance >= c.price
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.background = bg(0xFF261D3B.toInt(), 26f, if (afford) 0xFF7653A6.toInt() else 0xFF3B3152.toInt(), 1)
        col.setPadding(dp(8), dp(10), dp(8), dp(12))
        col.setOnClickListener { fx.play("click"); showCase(c) }

        val img = ImageView(this)
        img.setImageBitmap(bitmap(c.img))
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        col.addView(img, LinearLayout.LayoutParams(dp(110), dp(110)))
        val name = tv(c.name, 13f, Color.WHITE, true, true)
        name.maxLines = 2
        name.ellipsize = android.text.TextUtils.TruncateAt.END
        name.minLines = 2
        col.addView(name, LinearLayout.LayoutParams(MATCH, WRAP))
        val price = tv("🪙 " + GameData.money(c.price.toLong()), 15f, if (afford) GOLD else RED, true, true)
        col.addView(price, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        return col
    }

    private fun showCase(c: Case) {
        if (busy) return
        currentCase = c
        content.removeAllViews()
        content.addView(buildCaseDetail(c), FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun openLabel(c: Case): String = "ОТКРЫТЬ ×$openCount  ·  🪙 ${GameData.money(c.price.toLong() * openCount)}"

    private fun buildCaseDetail(c: Case): View {
        openCount = 1
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(8), dp(12), dp(24))
        sv.addView(col)

        val back = tv("‹ Все кейсы", 15f, MUTED, true)
        back.setPadding(dp(4), dp(8), dp(4), dp(8))
        back.setOnClickListener { fx.play("click"); selectTab(0) }
        col.addView(back)

        col.addView(tv(c.name, 20f, Color.WHITE, true, true), LinearLayout.LayoutParams(MATCH, WRAP))

        val roulette = RouletteView(this) { bitmap(it.img) }
        roulette.setIdle(List(12) { c.roll(rnd) })
        col.addView(roulette, LinearLayout.LayoutParams(MATCH, dp(140)).apply { topMargin = dp(10) })

        val countRow = LinearLayout(this)
        countRow.gravity = Gravity.CENTER
        countRow.background = bg(PANEL, 18f)
        val minus = button("−", PANEL2) { openCount = maxOf(1, openCount - 1); countLabel.text = "×$openCount"; caseOpenButton?.text = openLabel(c) }
        countLabel = tv("×1", 17f, Color.WHITE, true, true)
        val plus = button("+", PANEL2) { openCount = minOf(10, openCount + 1); countLabel.text = "×$openCount"; caseOpenButton?.text = openLabel(c) }
        countRow.addView(minus, LinearLayout.LayoutParams(dp(54), WRAP))
        countRow.addView(countLabel, LinearLayout.LayoutParams(dp(72), WRAP))
        countRow.addView(plus, LinearLayout.LayoutParams(dp(54), WRAP))
        col.addView(countRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        val fastToggle = button(if (store.fastOpen) "⚡ Быстрое открытие: ВКЛ" else "⚡ Быстрое открытие: ВЫКЛ", PANEL2) {
            store.fastOpen = !store.fastOpen; store.save()
            fastToggleText?.text = if (store.fastOpen) "⚡ Быстрое открытие: ВКЛ" else "⚡ Быстрое открытие: ВЫКЛ"
        }
        fastToggleText = fastToggle
        col.addView(fastToggle, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        val openBtn = button(openLabel(c), GREEN) {}
        caseOpenButton = openBtn
        col.addView(openBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        // Результаты показываются отдельными карточками — по одной на каждый кейс.
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = bg(PANEL, 22f)
        panel.setPadding(dp(12), dp(12), dp(12), dp(12))
        panel.visibility = View.GONE
        val resultTitle = tv("РЕЗУЛЬТАТЫ ОТКРЫТИЯ", 15f, Color.WHITE, true, true)
        panel.addView(resultTitle, LinearLayout.LayoutParams(MATCH, WRAP))
        val resultItems = LinearLayout(this)
        resultItems.orientation = LinearLayout.VERTICAL
        panel.addView(resultItems, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val sellBtn = button("Продать всё", GOLD, Color.BLACK) {}
        val keepBtn = button("Оставить всё", PANEL2) {}
        row.addView(sellBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(6) })
        row.addView(keepBtn, LinearLayout.LayoutParams(0, WRAP, 1f).apply { leftMargin = dp(6) })
        panel.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        col.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        // содержимое кейса с шансами
        col.addView(sectionTitle("Что внутри (шанс выпадения)"))
        val g = GridLayout(this)
        g.columnCount = 3
        for (drop in c.drops.sortedByDescending { it.item.value }) {
            addCell(g, itemCell(drop.item, null, "🪙 ${GameData.money(drop.item.value.toLong())}\n${fmt1(c.chance(drop))}", false) {})
        }
        col.addView(g)

        lastWins = emptyList()
        keepBtn.setOnClickListener { fx.play("click"); lastWins = emptyList(); panel.visibility = View.GONE }
        sellBtn.setOnClickListener {
            var total = 0L
            for (w in lastWins) if (store.remove(w.id, 1)) total += w.value
            if (total > 0) {
                store.balance += total
                store.save()
                fx.play("coin")
                updateBalance(true)
            }
            lastWins = emptyList()
            panel.visibility = View.GONE
        }

        openBtn.setOnClickListener {
            if (busy) return@setOnClickListener
            val totalCost = c.price.toLong() * openCount
            if (store.balance < totalCost) {
                toast("Не хватает монет. Награда раз в час, или продай предметы!")
                return@setOnClickListener
            }
            panel.visibility = View.GONE
            store.balance -= totalCost
            val wins = (0 until openCount).map { c.roll(rnd) }
            lastWins = wins
            wins.forEach {
                store.add(it.id)
                store.recordBest(it)
            }
            store.opened += openCount
            store.save()
            updateBalance(false)
            val saleTotal = wins.sumOf { it.value.toLong() }
            sellBtn.text = "Продать всё · 🪙 ${GameData.money(saleTotal)}"
            resultTitle.text = "ВЫПАЛО ПРЕДМЕТОВ: ${wins.size}"
            resultItems.removeAllViews()
            for ((index, item) in wins.withIndex()) {
                val card = LinearLayout(this)
                card.orientation = LinearLayout.HORIZONTAL
                card.gravity = Gravity.CENTER_VERTICAL
                card.background = bg(PANEL2, 16f)
                card.setPadding(dp(8), dp(8), dp(10), dp(8))
                val image = itemImage(item, dp(76))
                card.addView(image, LinearLayout.LayoutParams(dp(76), dp(76)))
                val details = LinearLayout(this)
                details.orientation = LinearLayout.VERTICAL
                details.setPadding(dp(10), 0, 0, 0)
                details.addView(tv("#${index + 1} · ${item.name}", 14f, GameData.rarityColor(item.value), true))
                details.addView(tv("${GameData.rarityName(item.value)} · 🪙 ${GameData.money(item.value.toLong())}", 12f, Color.WHITE))
                card.addView(details, LinearLayout.LayoutParams(0, WRAP, 1f))
                resultItems.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
            }

            val finishOpen = {
                busy = false
                openBtn.alpha = 1f
                panel.visibility = View.VISIBLE
                panel.scaleX = 0.94f
                panel.scaleY = 0.94f
                panel.alpha = 0f
                panel.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(300)
                    .setInterpolator(OvershootInterpolator(1.5f)).start()
                val bestWin = wins.maxByOrNull { it.value } ?: wins.last()
                val ratio = bestWin.value.toDouble() / c.price
                val rar = GameData.rarityColor(bestWin.value)
                when {
                    ratio >= 10 -> {
                        fx.play("win3"); fx.play("coin", 0.9f, 1.1f)
                        confetti.burst(240, 0.5f, 0.45f, 1.35f); confetti.rain(140)
                        flash(rar, 0.6f); shake(content)
                    }
                    ratio >= 3 -> {
                        fx.play("win3")
                        confetti.burst(150, 0.5f, 0.45f, 1.15f)
                        flash(rar, 0.42f)
                    }
                    ratio >= 1 -> {
                        fx.play("win2")
                        confetti.burst(60, 0.5f, 0.45f, 0.9f)
                        flash(rar, 0.25f)
                    }
                    else -> fx.play("win1")
                }
            }
            if (store.fastOpen) {
                finishOpen()
            } else {
                val len = 64
                val tIdx = 54 + rnd.nextInt(5)
                val strip = ArrayList<Item>()
                for (k in 0 until len) strip.add(c.roll(rnd))
                strip[tIdx] = wins.last()
                busy = true
                openBtn.alpha = 0.45f
                fx.play("whoosh", 0.8f)
                roulette.spin(strip, tIdx, 0.12f + 0.76f * rnd.nextFloat(), 6800,
                    { speed -> fx.tick(speed) }, { finishOpen() })
            }
        }
        return sv
    }

    // ---------- ИГРЫ ----------

    private fun buildGamesHub(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(24))
        }
        col.addView(tv("Игры", 25f, Color.WHITE, true))
        col.addView(tv("Выбери режим", 13f, MUTED), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        val up = button("✦  АПГРЕЙД\nУлучшай свои предметы", 0xFF49316F.toInt()) {
            content.removeAllViews(); content.addView(buildUpgrade(), FrameLayout.LayoutParams(MATCH, MATCH))
        }
        up.textSize = 17f
        col.addView(up, LinearLayout.LayoutParams(MATCH, dp(88)).apply { topMargin = dp(22) })
        val pl = button("●  PLINKO\nСтавь монеты и лови множитель", 0xFF315B68.toInt()) {
            content.removeAllViews(); content.addView(buildPlinko(), FrameLayout.LayoutParams(MATCH, MATCH))
        }
        pl.textSize = 17f
        col.addView(pl, LinearLayout.LayoutParams(MATCH, dp(88)).apply { topMargin = dp(12) })
        val earn = button("🪙  ЗАРАБОТОК
Посма, награды и монеты", 0xFF62458A.toInt()) {
            content.removeAllViews(); content.addView(buildEarn(), FrameLayout.LayoutParams(MATCH, MATCH))
        }
        earn.textSize = 16f
        col.addView(earn, LinearLayout.LayoutParams(MATCH, dp(82)).apply { topMargin = dp(12) })
        return col
    }

    private fun buildPlinko(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(24)) }
        sv.addView(col)
        val back = tv("‹ Игры", 15f, MUTED, true)
        back.setPadding(dp(4), dp(4), dp(4), dp(8))
        back.setOnClickListener { content.removeAllViews(); content.addView(buildGamesHub(), FrameLayout.LayoutParams(MATCH, MATCH)) }
        col.addView(back)
        col.addView(tv("PLINKO", 24f, Color.WHITE, true))
        col.addView(tv("Шарик стартует из центра. Всё решает случайность.", 12f, MUTED), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })

        val board = FrameLayout(this).apply { background = bg(0xFF211936.toInt(), 22f); clipToPadding = false }
        val boardHeight = dp(300)
        val ball = tv("●", 23f, GOLD, true, true)
        ball.setShadowLayer(dp(7).toFloat(), 0f, 0f, GOLD)
        val ballLp = FrameLayout.LayoutParams(dp(34), dp(34), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        ballLp.topMargin = dp(4)
        board.addView(ball, ballLp)
        // декоративные ряды штырьков
        for (row in 0 until 7) for (j in 0..(row + 2)) {
            val peg = tv("•", 20f, 0xFFB9AEC9.toInt(), true, true)
            val xFrac = (0.5f + (j - (row + 2) / 2f) * 0.105f).coerceIn(0.08f, 0.92f)
            val lp = FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.START)
            lp.leftMargin = (resources.displayMetrics.widthPixels * xFrac - dp(11)).toInt()
            lp.topMargin = dp(35 + row * 30)
            board.addView(peg, lp)
        }
        val multipliers = listOf("0.5x", "1x", "1.2x", "1.5x", "1.7x", "2x", "2.5x", "4x")
        val slots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; background = bg(PANEL, 12f); setPadding(dp(2), dp(7), dp(2), dp(7)) }
        multipliers.forEachIndexed { idx, value ->
            val cell = tv(value, 10f, if (idx == 0) RED else if (idx == 7) GOLD else Color.WHITE, true, true)
            slots.addView(cell, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        val boardCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(6), dp(6), dp(6)) }
        boardCol.addView(board, LinearLayout.LayoutParams(MATCH, boardHeight))
        boardCol.addView(slots, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(5) })
        col.addView(boardCol, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })

        val bet = EditText(this).apply {
            setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText("100"); setTextColor(Color.WHITE); setHintTextColor(MUTED); hint = "Ставка монет"
            background = bg(PANEL, 14f); setPadding(dp(14), dp(11), dp(14), dp(11))
        }
        col.addView(tv("Размер ставки", 13f, MUTED, true), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        col.addView(bet, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        val result = tv("Выбери ставку и запусти шарик", 14f, Color.WHITE, true, true)
        col.addView(result, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        val drop = button("БРОСИТЬ ШАРИК", GREEN) {}
        col.addView(drop, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        var running = false
        drop.setOnClickListener {
            if (running) return@setOnClickListener
            val stake = bet.text.toString().toLongOrNull() ?: 0L
            if (stake <= 0L || stake > store.balance) { toast("Укажи ставку в пределах баланса"); return@setOnClickListener }
            running = true; drop.isEnabled = false
            store.balance -= stake; store.save(); updateBalance(false)
            val weights = doubleArrayOf(7.0, 12.0, 13.0, 16.0, 16.0, 14.0, 12.0, 10.0)
            val total = weights.sum(); var pick = rnd.nextDouble() * total; var slot = 0
            while (slot < weights.lastIndex && pick >= weights[slot]) { pick -= weights[slot]; slot++ }
            val mult = doubleArrayOf(.5, 1.0, 1.2, 1.5, 1.7, 2.0, 2.5, 4.0)[slot]
            val payout = (stake * mult).toLong()
            val width = board.width.coerceAtLeast(dp(280))
            val endX = (width * ((slot + .5f) / 8f) - dp(17)).coerceIn(0f, (width - dp(34)).toFloat())
            ball.animate().cancel(); ball.translationX = 0f; ball.translationY = 0f
            ball.animate().translationY(dp(250).toFloat()).translationX(endX - (width - dp(34)) / 2f)
                .setDuration(1450).withEndAction {
                    store.balance += payout; store.save(); updateBalance(true)
                    val profit = payout - stake
                    result.text = "${mult}x  ·  выплата ${GameData.money(payout)} монет  ·  ${if (profit >= 0) "+" else ""}${GameData.money(profit)}"
                    result.setTextColor(if (profit >= 0) GREEN else RED)
                    val golden = rnd.nextInt(100) == 0
                    if (golden) {
                        store.balance += 500; store.save(); updateBalance(true)
                        result.text = "🌟 ЗОЛОТОЙ ШАР! +500 монет\n" + result.text
                        confetti.burst(180, .5f, .5f, 1.2f); flash(GOLD, .55f); fx.play("win3")
                    } else if (mult >= 2.5) { confetti.burst(90, .5f, .5f, .8f); flash(GOLD, .3f); fx.play("win1") }
                    else fx.play("coin")
                    running = false; drop.isEnabled = true
                }.start()
        }
        return sv
    }

    // ---------- АПГРЕЙД ----------

    private fun selValue(): Long {
        var s = 0L
        for ((id, n) in sel) s += (GameData.item(id)?.value ?: 0).toLong() * n
        return s
    }

    private fun upChance(sum: Long, t: Item): Double = min(0.95, sum.toDouble() / t.value * 0.92)

    private fun buildUpgrade(): View {
        sel.clear()
        target = null
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(8), dp(12), dp(24))
        sv.addView(col)

        wheel = WheelView(this)
        col.addView(wheel, LinearLayout.LayoutParams(dp(250), dp(250)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
        })
        upInfo = tv("", 14f, MUTED, true, true)
        col.addView(upInfo, LinearLayout.LayoutParams(MATCH, WRAP))
        upBtn = button("АПГРЕЙД", GREEN) { doUpgrade() }
        col.addView(upBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        val quickUpgrade = button(if (store.fastUpgrade) "⚡ Быстрый апгрейд: ВКЛ" else "⚡ Быстрый апгрейд: ВЫКЛ", PANEL2) {
            store.fastUpgrade = !store.fastUpgrade; store.save()
            upgradeFastToggle?.text = if (store.fastUpgrade) "⚡ Быстрый апгрейд: ВКЛ" else "⚡ Быстрый апгрейд: ВЫКЛ"
        }
        upgradeFastToggle = quickUpgrade
        col.addView(quickUpgrade, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        upResult = tv("", 15f, Color.WHITE, true, true)
        col.addView(upResult, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        col.addView(sectionTitle("1. Твои предметы (тап — добавить, ещё тап — больше копий)"))
        upMine = GridLayout(this)
        upMine.columnCount = 3
        col.addView(upMine)

        col.addView(sectionTitle("2. Цель (чем дороже — тем меньше шанс)"))
        upTargets = GridLayout(this)
        upTargets.columnCount = 3
        col.addView(upTargets)

        refreshUpgrade()
        return sv
    }

    private fun refreshUpgrade() {
        val sum = selValue()
        val t = target
        if (t != null && (sum <= 0 || t.value <= sum)) target = null
        val tt = target

        // мои предметы
        upMine.removeAllViews()
        val mine = store.inv.keys.mapNotNull { GameData.item(it) }.sortedByDescending { it.value }
        if (mine.isEmpty()) {
            upMine.addView(tv("Пока пусто. Открой кейсы!", 14f, MUTED, false, true))
        }
        for (item in mine) {
            val have = store.count(item.id)
            val picked = sel[item.id] ?: 0
            addCell(upMine, itemCell(item, if (picked > 0) "$picked/$have" else "x$have",
                "🪙 ${GameData.money(item.value.toLong())}", picked > 0) {
                if (busy) return@itemCell
                fx.play("click")
                val next = picked + 1
                if (next > have) sel.remove(item.id) else sel[item.id] = next
                upResult.text = ""
                refreshUpgrade()
            })
        }

        // цели
        upTargets.removeAllViews()
        if (sum <= 0) {
            upTargets.addView(tv("Сначала выбери свои предметы", 14f, MUTED, false, true))
        } else {
            val list = GameData.items.filter { it.value > sum && sum.toDouble() / it.value * 0.92 >= 0.02 }
                .sortedBy { it.value }.take(60)
            if (list.isEmpty()) upTargets.addView(tv("Нет целей дороже. Добавь предметов.", 14f, MUTED, false, true))
            for (item in list) {
                val ch = upChance(sum, item) * 100
                addCell(upTargets, itemCell(item, null, "🪙 ${GameData.money(item.value.toLong())}\n${fmt1(ch)}",
                    tt?.id == item.id) {
                    if (busy) return@itemCell
                    fx.play("click")
                    target = item
                    upResult.text = ""
                    refreshUpgrade()
                })
            }
        }

        // колесо и подписи
        if (tt != null && sum > 0) {
            val ch = upChance(sum, tt)
            wheel.chance = ch.toFloat()
            wheel.centerText = fmt1(ch * 100)
            wheel.subText = "шанс успеха"
            upInfo.text = "Ставка 🪙 ${GameData.money(sum)}  →  Цель 🪙 ${GameData.money(tt.value.toLong())}"
            upBtn.alpha = 1f
        } else {
            wheel.chance = 0f
            wheel.centerText = "—"
            wheel.subText = ""
            upInfo.text = if (sum > 0) "Ставка 🪙 ${GameData.money(sum)} — выбери цель" else "Выбери предметы и цель"
            upBtn.alpha = 0.45f
        }
    }

    private fun doUpgrade() {
        val t = target
        val sum = selValue()
        if (busy || t == null || sum <= 0) {
            toast("Выбери свои предметы и цель")
            return
        }
        val chance = upChance(sum, t)
        val win = rnd.nextDouble() < chance
        for ((id, n) in sel) store.remove(id, n)
        if (win) {
            store.add(t.id)
            store.recordBest(t)
        }
        store.save()

        busy = true
        upBtn.alpha = 0.45f
        upResult.text = ""
        fx.play("whoosh", 0.7f)
        val completeUpgrade = {
            busy = false
            if (win) {
                fx.play("up_ok")
                confetti.burst(170, 0.5f, 0.35f, 1.2f)
                flash(GREEN, 0.4f)
                upResult.text = "🎉 Успех! Получено: ${t.name}"
                upResult.setTextColor(GREEN)
            } else {
                fx.play("up_fail")
                shake(wheel)
                flash(RED, 0.25f)
                upResult.text = "💥 Не повезло. Предметы сгорели"
                upResult.setTextColor(RED)
            }
            sel.clear()
            target = null
            refreshUpgrade()
        }
        if (store.fastUpgrade) completeUpgrade() else wheel.spin(win, { fx.tick(0.35f) }, completeUpgrade)
    }

    // ---------- ЗАРАБОТОК ----------

    private fun buildEarn(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(30))
        }
        sv.addView(col)
        col.addView(tv("Заработок", 25f, Color.WHITE, true))
        col.addView(tv("Получай монеты и копи на новые кейсы", 13f, MUTED), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(5) })

        val five = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(0xFF302248.toInt(), 24f)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        five.addView(tv("⏱  БЫСТРАЯ НАГРАДА", 12f, MUTED, true))
        five.addView(tv("+10 монет", 25f, GOLD, true), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        earnFiveLabel = tv("Доступно", 13f, Color.WHITE, true)
        five.addView(earnFiveLabel, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        five.addView(button("Забрать 10 монет", 0xFF7653A6.toInt()) {
            if (store.claimFiveMinutes()) { fx.play("coin"); updateBalance(true); refreshEarnTimers(); confetti.burst(24, .8f, .05f, .6f) }
            else toast("Награда ещё восстанавливается")
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        col.addView(five, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(18) })

        val hour = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(0xFF302248.toInt(), 24f)
            setPadding(dp(18), dp(16), dp(18), dp(16))
        }
        hour.addView(tv("🎁  ЕЖЕЧАСНАЯ НАГРАДА", 12f, MUTED, true))
        hour.addView(tv("+100 монет", 25f, GOLD, true), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        earnHourLabel = tv("Доступно", 13f, Color.WHITE, true)
        hour.addView(earnHourLabel, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        hour.addView(button("Забрать 100 монет", 0xFF7653A6.toInt()) {
            if (store.claim()) { fx.play("coin"); updateBalance(true); refreshEarnTimers(); confetti.burst(36, .8f, .05f, .7f) }
            else toast("Награда ещё восстанавливается")
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        col.addView(hour, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        val click = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bg(0xFF392552.toInt(), 26f, 0xFF7653A6.toInt(), 1)
            setPadding(dp(18), dp(20), dp(18), dp(20))
        }
        click.addView(tv("КЛИКЕР ПОСМА", 13f, MUTED, true))
        click.addView(tv("+0,1 монеты за каждый клик", 15f, Color.WHITE, true))
        val counter = tv("Нажатий: $clickerClicks", 12f, MUTED)
        click.addView(counter, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(5) })
        val posma = ImageView(this).apply {
            setImageBitmap(assets.open("posma.png").use { BitmapFactory.decodeStream(it) })
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Посма — нажми, чтобы получить 0,1 монеты"
            isClickable = true
            isFocusable = true
            background = bg(0x00000000, 22f)
            setOnClickListener {
                store.addTenthCoin(); clickerClicks++
                updateBalance(true); counter.text = "Нажатий: $clickerClicks"
                animate().cancel()
                scaleX = 1f; scaleY = 1f
                animate().scaleX(.88f).scaleY(.88f).setDuration(65).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                }.start()
            }
        }
        click.addView(posma, LinearLayout.LayoutParams(dp(210), dp(205)).apply { topMargin = dp(8) })
        click.addView(tv("НАЖМИ НА ПОСМУ", 12f, 0xFFD7C4F5.toInt(), true), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        col.addView(click, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) })
        refreshEarnTimers()
        return sv
    }

    private fun refreshEarnTimers() {
        if (!::earnFiveLabel.isInitialized || !::earnHourLabel.isInitialized) return
        fun countdown(ms: Long): String {
            val sec = (ms / 1000).coerceAtLeast(0)
            return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
        }
        val five = store.fiveMinuteLeftMs()
        earnFiveLabel.text = if (five <= 0) "Награда доступна сейчас" else "Следующая награда через ${countdown(five)}"
        val hour = store.claimLeftMs()
        earnHourLabel.text = if (hour <= 0) "Награда доступна сейчас" else "Следующая награда через ${countdown(hour)}"
    }

    // ---------- ПРОФИЛЬ И ИНВЕНТАРЬ ----------

    private fun buildProfile(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(14), dp(14), dp(28))
        sv.addView(col)

        col.addView(tv("Профиль игрока", 22f, Color.WHITE, true, true), LinearLayout.LayoutParams(MATCH, WRAP))
        val avatar = ImageView(this)
        avatar.scaleType = ImageView.ScaleType.CENTER_CROP
        avatar.background = bg(PANEL2, 60f, 0xFF7777AA.toInt(), 2)
        avatar.setImageResource(android.R.drawable.sym_def_app_icon)
        store.avatarUri?.let { uri -> try { avatar.setImageURI(Uri.parse(uri)) } catch (_: Exception) {} }
        roundOutline(avatar, 60f)
        col.addView(avatar, LinearLayout.LayoutParams(dp(104), dp(104)).apply { gravity = Gravity.CENTER; topMargin = dp(16) })
        val avatarBtn = button("Изменить аватар", PANEL2) {
            val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(android.content.Intent.CATEGORY_OPENABLE); addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) }
            startActivityForResult(intent, 401)
        }
        col.addView(avatarBtn, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        val nick = EditText(this)
        nick.setSingleLine(true)
        nick.setText(store.nickname)
        nick.setTextColor(Color.WHITE)
        nick.setHintTextColor(MUTED)
        nick.hint = "Твой ник"
        nick.background = bg(PANEL, 16f)
        nick.setPadding(dp(16), dp(12), dp(16), dp(12))
        col.addView(nick, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })
        col.addView(button("Сохранить профиль", GREEN) {
            store.nickname = nick.text.toString().trim().ifBlank { "Игрок" }.take(20)
            store.save(); nick.setText(store.nickname); toast("Профиль сохранён")
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })


        val best = store.bestItemValue()
        val bestCard = LinearLayout(this)
        bestCard.orientation = LinearLayout.VERTICAL
        bestCard.background = bg(PANEL, 20f)
        bestCard.setPadding(dp(16), dp(14), dp(16), dp(14))
        bestCard.addView(tv("ТВОЙ ЛУЧШИЙ ЛОТ", 12f, MUTED, true))
        bestCard.addView(tv(store.bestItemName(), 17f, GOLD, true), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(5) })
        bestCard.addView(tv("🪙 ${GameData.money(best.toLong())} · всего предметов: ${store.totalCount()}", 13f, MUTED))
        col.addView(bestCard, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(16) })

        col.addView(sectionTitle("Инвентарь"))
        col.addView(tv("Предметов: ${store.totalCount()} · стоимость: 🪙 ${GameData.money(store.totalValue())}", 13f, MUTED, true))
        if (store.totalCount() > 0) col.addView(button("Продать всё", GOLD, Color.BLACK) { confirmSellAll() }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        val g = GridLayout(this); g.columnCount = 3
        val items = store.inv.keys.mapNotNull { GameData.item(it) }.sortedByDescending { it.value }
        if (items.isEmpty()) col.addView(tv("Пока нет предметов. Открой кейс!", 14f, MUTED, false, true), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(18) })
        for (item in items) addCell(g, itemCell(item, "x${store.count(item.id)}", "🪙 ${GameData.money(item.value.toLong())}", false) { itemDialog(item) })
        col.addView(g, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        col.addView(sectionTitle("Промокод"))
        col.addView(tv("Введи код и получи бонусные монеты", 12f, MUTED), LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        val promoInput = EditText(this).apply {
            setSingleLine(true)
            hint = "Введи промокод"
            setTextColor(Color.WHITE)
            setHintTextColor(MUTED)
            textSize = 15f
            background = bg(PANEL, 16f)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            filters = arrayOf(android.text.InputFilter.AllCaps(), android.text.InputFilter.LengthFilter(24))
        }
        col.addView(promoInput, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(button("Активировать промокод", PANEL2) {
            val result = store.redeemPromo(promoInput.text.toString())
            when (result) {
                is GameStore.PromoResult.Success -> {
                    updateBalance(true)
                    fx.play("coin")
                    confetti.burst(34, .8f, .05f, .65f)
                    promoInput.text.clear()
                    toast("Промокод активирован: +${GameData.money(result.coins)} монет")
                }
                GameStore.PromoResult.Empty -> toast("Введи промокод")
                GameStore.PromoResult.Invalid -> toast("Такого промокода нет")
                GameStore.PromoResult.AlreadyUsed -> toast("Этот промокод уже использован")
            }
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        return sv
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 401 && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                store.avatarUri = uri.toString()
                try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                store.save(); selectTab(3)
            }
        }
    }

    private fun buildInventory(): View {
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(12), dp(12), dp(24))
        sv.addView(col)

        col.addView(
            tv("Предметов: ${store.totalCount()}  ·  стоимость 🪙 ${GameData.money(store.totalValue())}", 15f, Color.WHITE, true, true),
            LinearLayout.LayoutParams(MATCH, WRAP)
        )
        col.addView(tv("Открыто кейсов: ${store.opened}", 12f, MUTED, false, true), LinearLayout.LayoutParams(MATCH, WRAP))

        if (store.totalCount() > 0) {
            val sellAll = button("Продать всё", GOLD, Color.BLACK) { confirmSellAll() }
            col.addView(sellAll, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) })
        }

        val g = GridLayout(this)
        g.columnCount = 3
        val items = store.inv.keys.mapNotNull { GameData.item(it) }.sortedByDescending { it.value }
        if (items.isEmpty()) {
            col.addView(tv("Тут пока пусто.\nОткрой кейс, и предметы появятся здесь.", 15f, MUTED, false, true),
                LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(40) })
        }
        for (item in items) {
            addCell(g, itemCell(item, "x${store.count(item.id)}", "🪙 ${GameData.money(item.value.toLong())}", false) {
                fx.play("click")
                itemDialog(item)
            })
        }
        col.addView(g, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        return sv
    }

    private fun darkDialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    private fun itemDialog(item: Item) {
        val n = store.count(item.id)
        if (n <= 0) return
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.gravity = Gravity.CENTER_HORIZONTAL
        v.setPadding(dp(16), dp(16), dp(16), dp(8))
        v.addView(itemImage(item, dp(160)))
        v.addView(tv(item.name, 17f, GameData.rarityColor(item.value), true, true),
            LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })
        v.addView(tv("${GameData.rarityName(item.value)} · 🪙 ${GameData.money(item.value.toLong())} · у тебя: $n",
            13f, MUTED, false, true), LinearLayout.LayoutParams(MATCH, WRAP))

        val b = darkDialog().setView(v)
            .setPositiveButton("Продать 1") { _, _ -> sell(item, 1) }
            .setNegativeButton("Закрыть", null)
        if (n > 1) b.setNeutralButton("Продать все ($n)") { _, _ -> sell(item, n) }
        b.show()
    }

    private fun sell(item: Item, n: Int) {
        if (!store.remove(item.id, n)) return
        store.balance += item.value.toLong() * n
        store.save()
        fx.play("coin")
        updateBalance(true)
        selectTab(3)
    }

    private fun confirmSellAll() {
        val total = store.totalValue()
        darkDialog()
            .setTitle("Продать всё?")
            .setMessage("Ты получишь 🪙 ${GameData.money(total)}")
            .setPositiveButton("Продать") { _, _ ->
                store.balance += total
                store.inv.clear()
                store.save()
                fx.play("coin")
                confetti.burst(60, 0.5f, 0.2f, 0.9f)
                updateBalance(true)
                selectTab(3)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}
