package com.example.camoverlay

import android.Manifest
import android.app.Dialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var stage: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var frameView: FrameView
    private lateinit var fakeButton: View
    private lateinit var settingsButton: View
    private lateinit var galleryButton: View
    private lateinit var shutterButton: View
    private lateinit var secretButton: View

    private var camera: Camera? = null
    private var useBack = true
    private var torchOn = false

    // жужжание пчелы раз в 5 секунд
    private val handler = Handler(Looper.getMainLooper())
    private var bee: MediaPlayer? = null
    private val buzz = object : Runnable {
        override fun run() {
            bee?.start()
            handler.postDelayed(this, 5000)
        }
    }

    private val prefs by lazy { getSharedPreferences("s", MODE_PRIVATE) }
    private val tileFile by lazy { File(filesDir, "tile.jpg") }
    private val dp by lazy { resources.displayMetrics.density }

    private val requestCamera =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else {
                Toast.makeText(this, "Нужен доступ к камере", Toast.LENGTH_LONG).show()
                finish()
            }
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let { u ->
                loadBitmap(u)?.let { bmp ->
                    frameView.tile = bmp
                    tileFile.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        stage = findViewById(R.id.stage)
        previewView = findViewById(R.id.previewView)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        frameView = findViewById(R.id.frameView)
        fakeButton = findViewById(R.id.fakeButton)
        settingsButton = findViewById(R.id.settingsButton)
        galleryButton = findViewById(R.id.galleryButton)
        shutterButton = findViewById(R.id.shutterButton)
        secretButton = findViewById(R.id.secretButton)
        secretButton.setOnClickListener { startActivity(Intent(this, HorrorActivity::class.java)) }

        frameView.tilesAcross = prefs.getInt("across", 7)
        frameView.tile = if (tileFile.exists()) BitmapFactory.decodeFile(tileFile.path)
                         else BitmapFactory.decodeResource(resources, R.drawable.guy)
        useBack = prefs.getBoolean("back", true)

        // кнопки держим внутри рамки
        stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateMargins() }

        shutterButton.setOnClickListener { takeShot() }
        galleryButton.setOnClickListener { finishAffinity() }     // «выключает приложение»
        fakeButton.setOnClickListener { toggleTorch() }           // фейк-настройки = фонарик
        settingsButton.setOnClickListener { showSettings() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else requestCamera.launch(Manifest.permission.CAMERA)
    }

    override fun onResume() {
        super.onResume()
        startBuzzing()
    }

    override fun onPause() {
        super.onPause()
        stopBuzzing()
    }

    private fun startBuzzing() {
        stopBuzzing()
        if (!prefs.getBoolean("bee", true)) return
        bee = MediaPlayer.create(this, R.raw.bee)
        handler.postDelayed(buzz, 5000)
    }

    private fun stopBuzzing() {
        handler.removeCallbacks(buzz)
        bee?.release()
        bee = null
    }

    private fun updateMargins() {
        if (stage.width == 0) return
        val t = stage.width / frameView.tilesAcross
        val pad = (8 * dp).toInt()
        fun View.setMargins(l: Int, tp: Int, r: Int, b: Int) {
            val lp = layoutParams as FrameLayout.LayoutParams
            if (lp.leftMargin != l || lp.topMargin != tp || lp.rightMargin != r || lp.bottomMargin != b) {
                lp.setMargins(l, tp, r, b)
                layoutParams = lp
            }
        }
        // Секретная кнопка точно накрывает нижнюю левую фотографию парня.
        val slp = secretButton.layoutParams as FrameLayout.LayoutParams
        if (slp.width != t || slp.height != t || slp.gravity != (Gravity.BOTTOM or Gravity.START)) {
            slp.width = t
            slp.height = t
            slp.gravity = Gravity.BOTTOM or Gravity.START
            slp.setMargins(0, 0, 0, 0)
            secretButton.layoutParams = slp
        }
        // правая — ровно в углу рамки, левая «фейковая» — чуть ниже и ближе к краю (несимметрично)
        settingsButton.setMargins(0, t + pad, t + pad, 0)
        fakeButton.setMargins(t + pad + (6 * dp).toInt(), t + pad + (10 * dp).toInt(), 0, 0)
        galleryButton.setMargins(t + pad, 0, 0, t + pad)
        shutterButton.setMargins(0, 0, 0, t + pad)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val selector = if (useBack) CameraSelector.DEFAULT_BACK_CAMERA
                           else CameraSelector.DEFAULT_FRONT_CAMERA
            try {
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, selector, preview)
                if (torchOn) camera?.cameraControl?.enableTorch(true)
            } catch (e: Exception) {
                Toast.makeText(this, "Камера недоступна", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleTorch() {
        val cam = camera ?: return
        if (!cam.cameraInfo.hasFlashUnit()) {
            Toast.makeText(this, "У этой камеры нет вспышки", Toast.LENGTH_SHORT).show()
            return
        }
        torchOn = !torchOn
        cam.cameraControl.enableTorch(torchOn)
    }

    private fun showSettings() {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_settings, null)
        var lang = prefs.getInt("lang", L.EGYPT)

        val title = v.findViewById<TextView>(R.id.settingsTitle)
        val langLabel = v.findViewById<TextView>(R.id.langLabel)
        val sizeLabel = v.findViewById<TextView>(R.id.sizeLabel)
        val spinner = v.findViewById<Spinner>(R.id.langSpinner)
        val seek = v.findViewById<SeekBar>(R.id.sizeSeek)
        val pickBtn = v.findViewById<Button>(R.id.pickPhoto)
        val resetBtn = v.findViewById<Button>(R.id.resetPhoto)
        val frontSw = v.findViewById<SwitchCompat>(R.id.frontSwitch)
        val beeSw = v.findViewById<SwitchCompat>(R.id.beeSwitch)
        val bear = v.findViewById<ImageView>(R.id.bearItem)
        val doneBtn = v.findViewById<Button>(R.id.doneButton)

        fun applyTexts() {
            val t = L.all[lang]
            title.text = t.getValue("title")
            langLabel.text = t.getValue("lang")
            sizeLabel.text = t.getValue("size")
            pickBtn.text = t.getValue("pick")
            resetBtn.text = t.getValue("reset")
            frontSw.text = t.getValue("front")
            beeSw.text = t.getValue("bee")
            doneBtn.text = t.getValue("done")
        }
        applyTexts()

        // язык интерфейса настроек
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, L.names).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        spinner.setSelection(lang, false)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                if (pos != lang) {
                    lang = pos
                    prefs.edit().putInt("lang", lang).apply()
                    applyTexts()
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // ползунок вправо = фотки крупнее (меньше штук по ширине)
        seek.progress = 20 - frameView.tilesAcross
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                frameView.tilesAcross = 20 - p
                prefs.edit().putInt("across", frameView.tilesAcross).apply()
                updateMargins()
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })

        pickBtn.setOnClickListener { pickImage.launch("image/*") }
        resetBtn.setOnClickListener {
            tileFile.delete()
            frameView.tile = BitmapFactory.decodeResource(resources, R.drawable.guy)
        }

        frontSw.isChecked = !useBack
        frontSw.setOnCheckedChangeListener { _, checked ->
            useBack = !checked
            prefs.edit().putBoolean("back", useBack).apply()
            startCamera()
        }

        beeSw.isChecked = prefs.getBoolean("bee", true)
        beeSw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("bee", checked).apply()
            if (checked) startBuzzing() else stopBuzzing()
        }

        bear.setOnClickListener { showBamboo() }

        val dlg = AlertDialog.Builder(this).setView(v).create()
        doneBtn.setOnClickListener { dlg.dismiss() }
        dlg.show()
    }

    /** Бамбук на весь экран ровно на 2 секунды. */
    private fun showBamboo() {
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.bamboo)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        d.setContentView(iv)
        d.setCancelable(false)
        d.show()
        iv.postDelayed({
            if (!isFinishing && d.isShowing) d.dismiss()
        }, 2000)
    }

    /** Кадр камеры + рамка -> галерея. */
    private fun takeShot() {
        val frame = previewView.bitmap ?: run {
            Toast.makeText(this, "Камера ещё не готова", Toast.LENGTH_SHORT).show()
            return
        }
        val result = frame.copy(Bitmap.Config.ARGB_8888, true)
        val k = result.width.toFloat() / previewView.width
        val canvas = Canvas(result)
        canvas.scale(k, k)
        frameView.draw(canvas)
        saveToGallery(result)
    }

    private fun saveToGallery(bmp: Bitmap) {
        val name = "CamFrame_" +
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CamOverlay")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            Toast.makeText(this, "Не удалось сохранить", Toast.LENGTH_SHORT).show()
            return
        }
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        Toast.makeText(this, "Сохранено в Pictures/CamOverlay", Toast.LENGTH_SHORT).show()
    }

    /** Загружает картинку из галереи, уменьшает и учитывает поворот из EXIF. */
    private fun loadBitmap(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1500) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, opts)
        } ?: return null

        val degrees = try {
            contentResolver.openInputStream(uri)?.use {
                when (ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (e: Exception) { 0f }

        if (degrees == 0f) return bmp
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }
}
